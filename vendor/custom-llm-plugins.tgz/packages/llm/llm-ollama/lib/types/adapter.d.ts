/**
 * `OllamaAdapter`: fetch + SSE against a local Ollama server's OpenAI-compatible
 * chat-completions endpoint, emitting harness StreamChunks. The adapter is
 * transport-only: connection facts arrive through a thunk resolved once per
 * operation, so the registering plugin owns validation and layering. No API
 * key exists — the server is local and unauthenticated.
 *
 * @module dsh-llm-ollama/adapter
 */
import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, LlmModelInfo, LlmProviderInfo, LlmResolvedModelInfo, ResolvedRetryPolicy, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { WireError } from './types.ts';
/** One optional model entry advertised by the adapter; omitted entries resolve dynamically from `/api/tags`. */
export interface OllamaCatalogModel {
    /** Wire model id accepted by the configured endpoint. */
    id: string;
    /** Selector label; defaults to {@link id}. */
    name?: string;
    /** Optional selector detail. */
    description?: string;
    /** Known combined request/response context capacity; omitted when deployment metadata is unavailable. */
    contextWindow?: number;
    /** Per-request output cap; omission falls back to the connection default. */
    maxTokens?: number;
}
/**
 * Validated connection facts for one operation. The plugin's
 * `resolveAdapterOptions` is the one explicit resolve step producing this
 * shape; the adapter trusts it and re-reads it per operation, which is what
 * makes a configuration change reach the next request without re-registration.
 */
export interface OllamaConnectionOptions {
    /** Ollama server root; `/v1/chat/completions` and `/api/tags` are appended. */
    baseURL: string;
    /** Default per-request output cap; explicit request values win. */
    maxTokens: number;
    /** Positive context capacity used when the selected model has no exact value. */
    defaultContextWindow: number;
    /** Advisory models exposed to discovery consumers; empty means resolve from `/api/tags`. */
    models: readonly OllamaCatalogModel[];
    /** Maximum provider idle time while one stream read is outstanding. */
    streamIdleTimeoutMs: number;
    /** Provider-owned model-request retry policy, already resolved. */
    retryPolicy: ResolvedRetryPolicy;
}
/** Constructor options for {@link OllamaAdapter}: the operation-local resolution hook the plugin owns. */
export interface OllamaAdapterOptions {
    /** Current validated connection facts; called once per operation. */
    options: () => OllamaConnectionOptions;
}
/** Default maximum idle interval while an adapter stream read is outstanding. */
export declare const DEFAULT_STREAM_IDLE_TIMEOUT_MS = 300000;
/** Default combined request/response context capacity for local models. */
export declare const DEFAULT_CONTEXT_WINDOW = 32768;
/** Default per-request output-token cap for local models. */
export declare const DEFAULT_MAX_TOKENS = 8192;
/** A conservative context capacity per model family, used when no exact value is known. */
export declare function contextWindowForModel(id: string, fallback: number): number;
/**
 * Map an HTTP status to a stable LlmError code.
 * @param status - status of a non-2xx provider response.
 * @param error - parsed provider error body, when available.
 * @returns the normalized harness error code.
 */
export declare function httpErrorCode(status: number, error?: WireError['error']): string;
/**
 * The local Ollama adapter. One instance serves every model name it was
 * registered under (the harness model name IS the wire model name).
 *
 * One stable signal reaches both initial fetch and body reads. Caller aborts
 * map to `ABORTED`; the configured per-read idle watchdog maps to `TIMEOUT`.
 */
export declare class OllamaAdapter extends LlmAdapter {
    private readonly config;
    /** Catalog cache: /api/tags is cheap but the Models page and creation flow list it repeatedly. */
    private cachedTags;
    constructor(config: OllamaAdapterOptions);
    providerInfo(provider: string): LlmProviderInfo;
    providerRetryPolicy(_provider: string): ResolvedRetryPolicy;
    /** Fetch the local catalog, cached briefly. */
    private tags;
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string, _signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    private request;
}
//# sourceMappingURL=adapter.d.ts.map