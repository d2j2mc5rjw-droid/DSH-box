/**
 * Ollama OpenAI-compatible chat-completions wire format (`/v1`). Types only.
 *
 * Ollama serves an OpenAI-compatible surface at `{baseURL}/v1/chat/completions`
 * and its native catalog at `{baseURL}/api/tags`. The chat wire shapes below
 * mirror the OpenAI vocabulary Ollama implements; fields Ollama does not
 * understand (e.g. `thinking`) are deliberately absent.
 *
 * @module dsh-llm-ollama/types
 */
/** Request body for `POST {baseURL}/v1/chat/completions`. */
export interface WireRequest {
    model: string;
    messages: WireMessage[];
    stream: true;
    /** Ollama reports usage on the terminal chunk; the flag is harmless if unsupported. */
    stream_options?: {
        include_usage: true;
    };
    tools?: WireTool[];
    temperature?: number;
    max_tokens?: number;
    stop?: string[];
}
/** System-role message: a single string of instructions. */
export interface WireSystemMessage {
    role: 'system';
    content: string;
}
/** User-role message: a single string of user input. */
export interface WireUserMessage {
    role: 'user';
    content: string;
}
/** Tool-role message: the result of one tool call, keyed by its call id. */
export interface WireToolMessage {
    role: 'tool';
    tool_call_id: string;
    content: string;
}
/** One entry of the request `messages` array, discriminated on `role`. */
export type WireMessage = WireSystemMessage | WireUserMessage | WireAssistantMessage | WireToolMessage;
/**
 * Assistant-role history message. The harness replays `content: ""` (never
 * null) on tool-call-only turns; Ollama accepts both, so keep the same rule.
 */
export interface WireAssistantMessage {
    role: 'assistant';
    content: string | null;
    tool_calls?: WireToolCall[];
}
/** A completed tool call replayed on an assistant history message; `arguments` is the raw JSON string. */
export interface WireToolCall {
    id: string;
    type: 'function';
    function: {
        name: string;
        arguments: string;
    };
}
/** One entry of the request `tools` array; `parameters` is a JSON Schema object. */
export interface WireTool {
    type: 'function';
    function: {
        name: string;
        description: string;
        parameters: Record<string, unknown>;
    };
}
/** One parsed SSE `data:` payload (a chat.completion.chunk). */
export interface WireChunk {
    choices?: WireChoice[];
    /** Ollama attaches usage to the final chunk. */
    usage?: WireUsage | null;
}
/** One streamed choice (requests always ask for a single one); `finish_reason` is non-null only on its terminal chunk. */
export interface WireChoice {
    delta?: WireDelta;
    finish_reason?: string | null;
}
/** The incremental content of one streamed choice; any subset of fields may be present per chunk. */
export interface WireDelta {
    role?: string;
    /** Visible text. Null/empty on tool-call chunks. */
    content?: string | null;
    tool_calls?: WireToolCallDelta[];
}
/** A streamed fragment of one tool call; fragments sharing an `index` concatenate into one call. */
export interface WireToolCallDelta {
    /** Disambiguates parallel tool calls; stable across a call's deltas. */
    index: number;
    /** Present on the first delta of each call only. */
    id?: string;
    type?: 'function';
    function?: {
        /** Present on the first delta of each call only. */
        name?: string;
        /** Argument JSON fragment (concatenate across deltas). */
        arguments?: string;
    };
}
/**
 * Wire token accounting (OpenAI spelling). Ollama fills
 * `prompt_tokens` / `completion_tokens` / `total_tokens`; the optional
 * details fields are read when present.
 */
export interface WireUsage {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens?: number;
    prompt_tokens_details?: {
        cached_tokens?: number;
    };
    completion_tokens_details?: {
        reasoning_tokens?: number;
    };
}
/** Non-2xx error body. */
export interface WireError {
    error?: {
        message?: string;
        type?: string;
        code?: string;
    };
}
/** One entry of `GET {baseURL}/api/tags` (`models`). */
export interface OllamaTagModel {
    name: string;
    model?: string;
    modified_at?: string;
    size?: number;
    digest?: string;
    details?: {
        parent_model?: string;
        format?: string;
        family?: string;
        families?: string[];
        parameter_size?: string;
        quantization_level?: string;
    };
}
/** Response body of `GET {baseURL}/api/tags`. */
export interface OllamaTagsResponse {
    models?: OllamaTagModel[];
}
//# sourceMappingURL=types.d.ts.map