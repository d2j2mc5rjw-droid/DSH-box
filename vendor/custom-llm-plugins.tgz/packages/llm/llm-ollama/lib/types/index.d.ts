/**
 * Register an {@link OllamaAdapter} for the `ollama` provider route on
 * `ctx.llm`, with connection facts resolved per request instead of frozen at
 * load: the plugin layers its `cordis.yml` entry config under the optional
 * `llm-ollama` user-settings section (`ctx.settings`), so a changed base URL
 * or catalog reaches the very next request without restarting anything,
 * while an in-flight stream keeps the facts it started with. Local Ollama
 * needs no API key, so no credential seam is involved. The one
 * registration-captured fact — the retry policy — re-registers the route in
 * place when it changes.
 * @module @deepseek-ai/dsh-llm-ollama
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { RetryPolicyConfig } from '@deepseek-ai/dsh-llm';
import type { OllamaCatalogModel, OllamaConnectionOptions } from './adapter.ts';
export { DEFAULT_CONTEXT_WINDOW, DEFAULT_MAX_TOKENS, DEFAULT_STREAM_IDLE_TIMEOUT_MS, OllamaAdapter, contextWindowForModel, } from './adapter.ts';
export type { OllamaAdapterOptions, OllamaCatalogModel, OllamaConnectionOptions } from './adapter.ts';
export type * from './types.ts';
export declare const name = "llm-ollama";
export declare const inject: string[];
/** Default local Ollama server root. */
export declare const DEFAULT_BASE_URL = "http://localhost:11434";
/**
 * Plugin config, validated by the same-named schemastery schema and doubling
 * as the `llm-ollama` settings-section shape. Every field is optional in yml:
 * the base URL defaults to the local server, the model catalog resolves
 * dynamically from `/api/tags` when `models` is omitted.
 */
export interface Config {
    /** Ollama server root (default `http://localhost:11434`); honors `$OLLAMA_HOST` when unset. */
    baseURL?: string;
    /** Default per-request output cap (default 8,192). */
    maxTokens?: number;
    /** Positive context capacity used when a model family has no exact value (default 32,768). */
    defaultContextWindow?: number;
    /** Advisory models; empty resolves the catalog from `/api/tags`. */
    models?: OllamaCatalogModel[];
    /** Maximum provider idle time while one stream read is outstanding (default five minutes). */
    streamIdleTimeoutMs?: number;
    /** Provider-owned model-request retry policy; omission uses normal defaults. */
    retryPolicy?: RetryPolicyConfig;
}
export declare const Config: z<Config>;
/**
 * The one explicit resolve step from raw config to validated connection
 * facts. Programmatic construction may bypass Schemastery normalization, so
 * every default and bound is re-judged here — for the composition entry at
 * load (fail loud) and for each settings snapshot at its first use.
 * @param config - raw plugin config or resolved settings snapshot.
 * @returns validated connection facts.
 */
export declare function resolveAdapterOptions(config: Config): OllamaConnectionOptions;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map