import { describe, expect, it, vi, afterEach } from 'vitest'
import { createUserMessage, CallId, createMessage } from '@deepseek-ai/dsh-llm'
import type { GenerateOptions } from '@deepseek-ai/dsh-llm'
import { serializeMessages, serializeRequest } from '../src/serialize.ts'
import { mapFinishReason, mapUsage, translate } from '../src/translate.ts'
import { OllamaAdapter, contextWindowForModel, DEFAULT_CONTEXT_WINDOW, DEFAULT_MAX_TOKENS } from '../src/adapter.ts'
import { DONE } from '../src/sse.ts'

function request(overrides: Partial<GenerateOptions> = {}): GenerateOptions {
  return { provider: 'ollama', model: 'qwen2.5:0.5b', messages: [], ...overrides }
}

describe('serializeMessages', () => {
  it('maps user text to string content', () => {
    const wire = serializeMessages([
      createUserMessage({
        content: [{ type: 'text', text: 'hello ' }, { type: 'text', text: 'world' }],
        source: { kind: 'plugin', plugin: 'test' },
      }),
    ])
    expect(wire).toEqual([{ role: 'user', content: 'hello world' }])
  })

  it('expands tool results into role:tool messages', () => {
    const wire = serializeMessages([
      createUserMessage({
        content: [
          { type: 'tool-result', toolCallId: CallId('call-1'), content: [{ type: 'text', text: '42' }] },
        ],
        source: { kind: 'plugin', plugin: 'test' },
      }),
    ])
    expect(wire).toEqual([{ role: 'tool', tool_call_id: 'call-1', content: '42' }])
  })

  it('rejects image content', () => {
    expect(() => serializeMessages([
      createUserMessage({
        content: [{ type: 'image', image: { kind: 'attachment', attachmentId: 'a-1' as never } }],
        source: { kind: 'plugin', plugin: 'test' },
      }),
    ])).toThrow(/does not support image content/)
  })
})

describe('serializeRequest', () => {
  it('builds the OpenAI-compatible body without thinking fields', () => {
    const body = serializeRequest(request({
      system: 'be brief',
      messages: [createUserMessage({ content: [{ type: 'text', text: 'hi' }], source: { kind: 'plugin', plugin: 'test' } })],
      temperature: 0.2,
      maxTokens: 128,
      tools: [{
        name: 'list_dir',
        description: 'list a directory',
        parameters: { type: 'object', properties: {} },
      }],
    }))
    expect(body).toEqual({
      model: 'qwen2.5:0.5b',
      messages: [
        { role: 'system', content: 'be brief' },
        { role: 'user', content: 'hi' },
      ],
      stream: true,
      stream_options: { include_usage: true },
      tools: [{ type: 'function', function: { name: 'list_dir', description: 'list a directory', parameters: { type: 'object', properties: {} } } }],
      temperature: 0.2,
      max_tokens: 128,
    })
    expect(body).not.toHaveProperty('thinking')
    expect(body).not.toHaveProperty('reasoning_effort')
  })
})

describe('mapFinishReason / mapUsage', () => {
  it('maps stop/tool_calls/length', () => {
    expect(mapFinishReason('stop')).toEqual({ kind: 'stop' })
    expect(mapFinishReason('tool_calls')).toEqual({ kind: 'tool-calls' })
    expect(mapFinishReason('length')).toEqual({ kind: 'max-tokens' })
    expect(mapFinishReason('content_filter')).toEqual({
      kind: 'error',
      failure: { message: 'model stopped: content_filter', code: 'CONTENT_FILTER' },
    })
  })

  it('maps usage with disjoint cached-token accounting', () => {
    expect(mapUsage({ prompt_tokens: 100, completion_tokens: 50 }))
      .toEqual({ inputTokens: 100, outputTokens: 50 })
    expect(mapUsage({
      prompt_tokens: 100,
      completion_tokens: 50,
      prompt_tokens_details: { cached_tokens: 30 },
      completion_tokens_details: { reasoning_tokens: 10 },
    })).toEqual({ inputTokens: 70, outputTokens: 50, cacheReadTokens: 30, reasoningTokens: 10 })
  })
})

describe('translate', () => {
  async function collect(payloads: string[]) {
    const source = (async function* () { yield* payloads })()
    const chunks = []
    for await (const chunk of translate(source)) chunks.push(chunk)
    return chunks
  }

  it('assembles text deltas and defers finish to [DONE]', async () => {
    const chunks = await collect([
      JSON.stringify({ choices: [{ delta: { content: '你' } }] }),
      JSON.stringify({ choices: [{ delta: { content: '好' }, finish_reason: 'stop' }], usage: { prompt_tokens: 3, completion_tokens: 2 } }),
      DONE,
    ])
    expect(chunks).toMatchObject([
      { type: 'block-start', blockType: 'text' },
      { type: 'text-delta', text: '你' },
      { type: 'text-delta', text: '好' },
      { type: 'block-end', block: { type: 'text', text: '你好' } },
      { type: 'usage', usage: { inputTokens: 3, outputTokens: 2 } },
      { type: 'finish', reason: { kind: 'stop' } },
    ])
  })

  it('assembles tool-call fragments into one call', async () => {
    const chunks = await collect([
      JSON.stringify({ choices: [{ delta: { tool_calls: [{ index: 0, id: 'call-1', function: { name: 'list_dir', arguments: '{"pa' } }] } }] }),
      JSON.stringify({ choices: [{ delta: { tool_calls: [{ index: 0, function: { arguments: 'th":"."}' } }] }, finish_reason: 'tool_calls' }] }),
      DONE,
    ])
    expect(chunks).toMatchObject([
      { type: 'block-start', blockType: 'tool-call' },
      { type: 'tool-call-delta', id: 'call-1', name: 'list_dir', argumentsDelta: '{"pa' },
      { type: 'tool-call-delta', argumentsDelta: 'th":"."}' },
      { type: 'block-end', block: { type: 'tool-call', id: 'call-1', name: 'list_dir', arguments: '{"path":"."}' } },
      { type: 'finish', reason: { kind: 'tool-calls' } },
    ])
  })

  it('throws on malformed payload', async () => {
    await expect(collect(['not json', DONE])).rejects.toThrow('malformed SSE payload')
  })
})

describe('contextWindowForModel', () => {
  it('picks family capacities with the connection fallback', () => {
    expect(contextWindowForModel('gpt-oss:20b', 8192)).toBe(131_072)
    expect(contextWindowForModel('qwen2.5-coder:7b', 8192)).toBe(32_768)
    expect(contextWindowForModel('deepseek-r1:8b', 8192)).toBe(16_384)
    expect(contextWindowForModel('codellama:7b', 8192)).toBe(16_384)
    expect(contextWindowForModel('smollm2:135m', 8192)).toBe(8192)
  })
})

describe('OllamaAdapter listModels', () => {
  afterEach(() => vi.unstubAllGlobals())

  it('resolves the catalog from /api/tags when no static models are configured', async () => {
    const tags = {
      models: [
        { name: 'qwen2.5:0.5b', details: { parameter_size: '494M', quantization_level: 'Q4_K_M' } },
        { name: 'gpt-oss:20b-cloud', details: { parameter_size: '20.9B' } },
      ],
    }
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify(tags), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    })))

    const adapter = new OllamaAdapter({
      options: () => ({
        baseURL: 'http://localhost:11434',
        maxTokens: DEFAULT_MAX_TOKENS,
        defaultContextWindow: DEFAULT_CONTEXT_WINDOW,
        models: [],
        streamIdleTimeoutMs: 300_000,
        retryPolicy: { maxAttempts: 1 },
      }),
    })
    const models = await adapter.listModels('ollama')
    expect(models).toEqual([
      expect.objectContaining({ id: 'qwen2.5:0.5b', name: 'qwen2.5:0.5b', description: '494M · Q4_K_M' }),
      expect.objectContaining({ id: 'gpt-oss:20b-cloud' }),
    ])
    expect(fetch).toHaveBeenCalledWith('http://localhost:11434/api/tags', expect.anything())
  })
})
