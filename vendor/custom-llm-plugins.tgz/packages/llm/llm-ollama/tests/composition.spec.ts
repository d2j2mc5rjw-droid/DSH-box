/**
 * Real-composition guard for the Ollama adapter chain: LlmRuntime and
 * llm-ollama boot from a test-only cordis.yml through the actual Loader +
 * Include path, the `ollama` provider route registers, and a mocked
 * Ollama `/v1/chat/completions` SSE response flows through serialize → fetch
 * → parse → translate → BlockAssembler exactly as production streams it.
 */

import { mkdtemp, rm, writeFile } from 'node:fs/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { pathToFileURL } from 'node:url'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { Context } from '@deepseek-ai/cordis'
import Loader from '@deepseek-ai/cordis-plugin-loader'
import Include from '@deepseek-ai/cordis-plugin-include'
import LlmRuntime, { BlockAssembler } from '@deepseek-ai/dsh-llm'
import type { GenerateOptions, Message, TokenUsage, FinishReason } from '@deepseek-ai/dsh-llm'
import * as LlmOllama from '@deepseek-ai/dsh-llm-ollama'

let root: string | undefined
let context: Context | undefined

afterEach(async () => {
  await context?.fiber.dispose()
  context = undefined
  if (root !== undefined) await rm(root, { recursive: true, force: true })
  root = undefined
  vi.unstubAllGlobals()
  vi.unstubAllEnvs()
})

/** Fake Ollama /v1 chat-completions SSE bytes. */
function sseResponse(events: object[]): Response {
  const body = events.map(event => `data: ${JSON.stringify(event)}\n\n`).join('') + 'data: [DONE]\n\n'
  return new Response(body, {
    status: 200,
    headers: { 'content-type': 'text/event-stream' },
  })
}

async function loadComposition(): Promise<Context> {
  root = await mkdtemp(join(tmpdir(), 'dsh-llm-ollama-composition-'))
  vi.stubEnv('DSH_HOME', root)
  const configPath = join(root, 'cordis.yml')
  await writeFile(configPath, [
    '- id: llm',
    "  name: 'test-llm-service'",
    '- id: llm-ollama',
    "  name: '@deepseek-ai/dsh-llm-ollama'",
    '  config:',
    '    baseURL: http://localhost:11434',
    '',
  ].join('\n'))

  const ctx = new Context()
  context = ctx
  ctx.baseUrl = pathToFileURL(root).href + '/'
  await ctx.plugin(Loader)
  ctx.loader.builtins.include = Include
  const modules = new Map<string, unknown>([
    ['test-llm-service', LlmRuntime],
    ['@deepseek-ai/dsh-llm-ollama', LlmOllama],
  ])
  ctx.loader.internal = {
    version: 'v2',
    async import(specifier: string) {
      if (!modules.has(specifier)) throw new Error(`unexpected Loader import: ${specifier}`)
      return modules.get(specifier)
    },
  } as unknown as NonNullable<typeof ctx.loader.internal>
  await ctx.loader.create({
    name: 'cordis:include',
    config: { path: pathToFileURL(configPath).href },
  })
  await ctx.loader.await()
  return ctx
}

async function assemble(ctx: Context, options: Omit<GenerateOptions, 'provider'> & { provider?: string }): Promise<{
  message: Message
  usage?: TokenUsage
  finish: FinishReason
}> {
  const assembler = new BlockAssembler()
  const request = { provider: 'ollama', ...options }
  for await (const chunk of ctx.llm.stream(request)) assembler.push(chunk)
  return {
    message: assembler.message({
      kind: 'model',
      provider: request.provider,
      model: request.model,
      ...assembler.replayState === undefined ? {} : { replayState: assembler.replayState },
    }),
    ...assembler.usage !== undefined ? { usage: assembler.usage } : {},
    finish: assembler.finish,
  }
}

describe('llm-ollama real composition', () => {
  it('registers the ollama provider route', async () => {
    const ctx = await loadComposition()
    const providers = ctx.llm.listProviders()
    expect(providers.map(provider => provider.id)).toContain('ollama')
    expect(providers.find(provider => provider.id === 'ollama')?.name).toBe('Ollama (本地)')
  })

  it('resolves a model with a family context window', async () => {
    const ctx = await loadComposition()
    const info = await ctx.llm.resolveModelInfo('ollama', 'qwen2.5:0.5b')
    expect(info.id).toBe('qwen2.5:0.5b')
    expect(info.context!.contextWindow).toBe(32_768)
    expect(info.defaultMaxTokens).toBe(8_192)
  })

  it('lists models from the live /api/tags catalog', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({
      models: [
        { name: 'qwen2.5:0.5b', details: { parameter_size: '494M', quantization_level: 'Q4_K_M' } },
        { name: 'gpt-oss:20b-cloud', details: { parameter_size: '20.9B' } },
      ],
    }), { status: 200 })))
    const ctx = await loadComposition()
    const models = await ctx.llm.listModels('ollama')
    expect(models.map(model => model.id)).toEqual(['qwen2.5:0.5b', 'gpt-oss:20b-cloud'])
  })

  it('streams a mocked Ollama response through the full harness path', async () => {
    const fetchMock = vi.fn(async () => sseResponse([
      { choices: [{ delta: { content: '你' } }] },
      { choices: [{ delta: { content: '好' }, finish_reason: 'stop' }], usage: { prompt_tokens: 10, completion_tokens: 2 } },
    ]))
    vi.stubGlobal('fetch', fetchMock)
    const ctx = await loadComposition()
    const result = await assemble(ctx, { model: 'qwen2.5:0.5b', messages: [] })
    expect(result.message.content).toEqual([{ type: 'text', text: '你好' }])
    expect(result.usage).toEqual({ inputTokens: 10, outputTokens: 2 })
    expect(result.finish).toEqual({ kind: 'stop' })
    // The request hit the Ollama OpenAI-compatible endpoint.
    const [url] = fetchMock.mock.calls[0]! as unknown as [string]
    expect(String(url)).toBe('http://localhost:11434/v1/chat/completions')
  })
})
