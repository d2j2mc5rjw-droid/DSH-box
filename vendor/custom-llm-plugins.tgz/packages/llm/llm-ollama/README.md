# @deepseek-ai/dsh-llm-ollama

Local [Ollama](https://ollama.com) adapter for the DeepSeek Harness LLM seam. Registers the
`ollama` provider route on `ctx.llm`, streaming through Ollama's OpenAI-compatible
`/v1/chat/completions` endpoint and resolving the model catalog dynamically from `/api/tags`.

## Plugin

- **name**: `llm-ollama`
- **inject**: `['llm']`
- **Config**: `llm-ollama:` section in the user settings document (`$DSH_HOME/settings.yaml`),
  doubling as the entry-config shape; hot-reloaded without restart.
- **Provider route**: `ollama`, display name `Ollama (本地)`, registered through
  `ctx.llm.registerConfigurableProviders` so the web Models page can select it.

| Config key | Default | Meaning |
|---|---|---|
| `baseURL` | `http://localhost:11434` | Ollama server root (`/v1/chat/completions` and `/api/tags` appended) |
| `maxTokens` | `8192` | Default per-request output cap |
| `defaultContextWindow` | `32768` | Context capacity for model families without an exact value |
| `models` | `[]` (dynamic) | Advisory static catalog; when empty, resolved from `/api/tags` |
| `streamIdleTimeoutMs` | `300000` | Max idle time while one stream read is outstanding |
| `retryPolicy` | normal defaults | Provider-owned model-request retry policy |

No API key exists for a local server, so no credential seam is involved.

## Adapter

`OllamaAdapter extends LlmAdapter`:

- `providerInfo` → `{ id: 'ollama', name: 'Ollama (本地)' }`
- `listModels` → `GET {baseURL}/api/tags` (cached 10s), mapping each tag to a model whose
  context capacity is chosen by family (`gpt-oss` → 128K, `qwen2.5`/`llama3` → 32K, `r1`/`codellama` → 16K)
- `resolveModel` → catalog entry or family heuristic with the connection default fallback; text-only
- `stream` → `POST {baseURL}/v1/chat/completions` (SSE), idle watchdog, harness error mapping
  (`AUTH` / `RATE_LIMIT` / `CONTEXT_WINDOW_EXCEEDED` / `INVALID_REQUEST` / `SERVER` / `TIMEOUT` / `ABORTED` / `TRANSPORT`)

Tool calling rides the standard OpenAI-compatible `tools` wire shape; Ollama models that declare
the `tools` capability participate like any other provider.

## Model Experience

### Request context and condition

#### What the model sees

The model sees the harness system prompt, conversation, and tool schemas serialized to the
OpenAI-compatible wire format; no adapter-owned prose is added. The model id is passed through
verbatim as `model`.

#### Token effect

Fixed, adapter-owned prompt overhead is zero — the wire body contains only the harness messages
and tool definitions. The `maxTokens` cap defaults to a modest 8192 because local models are
small; raise it per request or in settings for capable models.

#### KV Cache effect

Independent model request per stream: each call re-sends the full conversation, so Ollama's KV
cache reuse depends on its own prompt-prefix handling and eviction, outside this package's
contract. Nothing in this adapter invalidates a reusable prefix.

## Known Limitations and Deferred Work

- **Reasoning-only stream contents** — some local models (e.g. `deepseek-r1` via the native
  `/api/chat`) emit reasoning text that the OpenAI-compatible surface does not expose; the
  adapter does not surface reasoning blocks and treats the visible text stream as the answer.
- **No image inputs** — the wire route is text-only; image content is rejected with
  `UNSUPPORTED_CONTENT` before any text-flattening can silently erase it.
- **Context capacity is advisory** — Ollama's effective context is governed by the model
  definition and `OLLAMA_CONTEXT_LENGTH`; the catalog `contextWindow` only informs the harness
  budget and cannot raise the server-side limit.
- **Catalog cache TTL** — `/api/tags` is cached for 10 seconds, so a freshly pulled model can
  take up to that long to appear in the picker.
