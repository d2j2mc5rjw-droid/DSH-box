/**
 * save-login.mjs — 一次性登录 chat.deepseek.com，把登录态保存为 Playwright
 * storageState JSON（含 localStorage userToken 与全部会话 cookie）。
 *
 * 用法（在本包目录内，或任意位置）：
 *   node packages/llm/llm-deepseek-web/scripts/save-login.mjs [output.json]
 *   例：node packages/llm/llm-deepseek-web/scripts/save-login.mjs ~/.dsh/deepseek-web-login.json
 *
 * 会打开一个可见浏览器窗口；请在窗口里完成登录（扫码/手机号/账号密码），
 * 完成后回到终端按回车。脚本把登录态写入输出文件（默认 ./deepseek-web-login.json）。
 *
 * 之后在 settings.yaml（或 web profile 的 cordis.patch.yml）里配置：
 *   llm-deepseek-web:
 *     storageStatePath: /Users/<you>/.dsh/deepseek-web-login.json
 *
 * 备注：Playwright 会尝试复用全局安装的 playwright；找不到时提示先
 * `npm i -g playwright && playwright install chromium`。也可直接用
 * `npx playwright codegen --save-storage=<file> https://chat.deepseek.com/`。
 */
import { createRequire } from 'node:module'
import { execFileSync } from 'node:child_process'
import fs from 'node:fs'
import path from 'node:path'
import readline from 'node:readline'

const CHAT_URL = 'https://chat.deepseek.com/'

function resolvePlaywright() {
  const anchors = [
    path.join(execFileSync('npm', ['root', '-g'], { encoding: 'utf8', windowsHide: true }).trim(), 'playwright', 'package.json'),
    'playwright/package.json',
    path.resolve(import.meta.dirname, '../node_modules/playwright/package.json'),
  ]
  for (const anchor of anchors) {
    try { return createRequire(anchor)('playwright') } catch { /* next */ }
  }
  throw new Error('未找到 playwright，先运行：npm i -g playwright && playwright install chromium')
}

function waitForEnter(question) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout })
  return new Promise((resolve) => {
    rl.question(question + ' ', () => { rl.close(); resolve() })
  })
}

async function main() {
  const out = path.resolve(process.argv[2] || 'deepseek-web-login.json')
  const { chromium } = resolvePlaywright()
  console.log(`打开 ${CHAT_URL}，请在浏览器窗口里完成登录（扫码 / 手机号 / 账号密码）…`)
  const browser = await chromium.launch({ headless: false })
  const context = await browser.newContext()
  const page = await context.newPage()
  await page.goto(CHAT_URL, { waitUntil: 'domcontentloaded' })
  await waitForEnter('登录完成后，回到这里按回车保存登录态并关闭浏览器：')
  // localStorage 里的 userToken 与 HttpOnly cookie 都会被写进 storageState。
  const state = await context.storageState()
  fs.mkdirSync(path.dirname(out), { recursive: true })
  fs.writeFileSync(out, JSON.stringify(state, null, 2))
  await browser.close()
  const hasToken = (state.origins || []).some((o) =>
    o.origin.includes('chat.deepseek.com')
    && (o.localStorage || []).some((e) => e.name === 'userToken'))
  const hasCookie = (state.cookies || []).some((c) => c.name === 'user_token')
  if (!hasToken && !hasCookie) {
    console.error(`警告：${out} 里没有找到 chat.deepseek.com 的会话（userToken / user_token）。请确认已登录后重试。`)
    process.exitCode = 1
    return
  }
  console.log(`已保存登录态到 ${out}`)
  console.log('现在把它配到 settings.yaml：')
  console.log('  llm-deepseek-web:')
  console.log(`    storageStatePath: ${out}`)
}

main().catch((error) => {
  console.error(error)
  process.exitCode = 1
})
