/**
 * Web-DeepSeek authentication resolution.
 *
 * chat.deepseek.com does not need an API key: it authenticates with the
 * browser session's bearer token (`localStorage.userToken`, also mirrored in
 * the HttpOnly `user_token` cookie) plus the session cookies. This module
 * resolves those facts from a Playwright `storageState` JSON (the format the
 * `dsh-browser` plugin and `scripts/save-login.mjs` produce) or from a
 * credential reference naming an environment variable.
 *
 * Like the API-key adapters, every fact is resolved per request rather than
 * frozen at load, so a refreshed login reaches the very next model call.
 * @module dsh-llm-deepseek-web/auth
 */

import { readFileSync } from 'node:fs'
import { assertUsableApiKey, LlmError } from '@deepseek-ai/dsh-llm'
import type { CredentialProvider } from '@deepseek-ai/dsh-credentials'
import { credentialRef } from '@deepseek-ai/dsh-credentials'

/** Fallback token source: a Playwright storageState JSON (login capture). */
export const DEFAULT_TOKEN_ENV = 'DEEPSEEK_WEB_TOKEN'

/** Chrome-ish UA expected by the web origin; not authentication, only hygiene. */
export const WEB_USER_AGENT =
  'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'

/** A usable signed-in web session. */
export interface WebAuth {
  /** Bearer token for `Authorization: Bearer <token>`. */
  readonly token: string
  /** Session cookies to send on every web-origin request. */
  readonly cookies: Record<string, string>
  /** Where the token came from, for diagnostics. */
  readonly source: string
}

/** Playwright storageState JSON shape (subset). */
export interface StorageStateFile {
  cookies?: { name: string; value: string; domain?: string }[]
  origins?: { origin: string; localStorage?: { name: string; value: string }[] }[]
}

/** Parse a storageState document and extract the DeepSeek web session. */
export function webAuthFromStorageState(document: unknown, path: string): WebAuth | null {
  if (typeof document !== 'object' || document === null) return null
  const state = document as StorageStateFile
  const cookies: Record<string, string> = {}
  for (const cookie of state.cookies ?? []) {
    if (cookie === null || typeof cookie !== 'object') continue
    const domain = cookie.domain ?? ''
    if (!domain.includes('deepseek.com') && domain !== '') continue
    if (typeof cookie.name === 'string' && typeof cookie.value === 'string') {
      cookies[cookie.name] = cookie.value
    }
  }
  let token: string | undefined
  let source = `storageState ${path}`
  // The web app keeps its bearer token in localStorage; prefer it over the
  // HttpOnly cookie mirror (both are written by the same session). The site
  // stores the token JSON-wrapped (`{"value":"<token>","__version":"0"}`),
  // so unwrap a parsed `value` string; a plain-string token passes through.
  const unwrapToken = (raw: string, entrySource: string): { token: string; source: string } => {
    try {
      const parsed = JSON.parse(raw) as { value?: unknown }
      if (typeof parsed?.value === 'string' && parsed.value.length > 0) {
        return { token: parsed.value, source: `${entrySource}.value` }
      }
    } catch {
      // Not JSON: the raw string is the token itself.
    }
    return { token: raw, source: entrySource }
  }
  for (const origin of state.origins ?? []) {
    if (origin?.origin?.includes('chat.deepseek.com')) {
      for (const entry of origin.localStorage ?? []) {
        if (entry?.name === 'userToken' && typeof entry.value === 'string' && entry.value.length > 0) {
          const unwrapped = unwrapToken(entry.value, `storageState ${path} (localStorage userToken)`)
          token = unwrapped.token
          source = unwrapped.source
        }
      }
    }
  }
  if (token === undefined) {
    const cookieToken = cookies['user_token'] ?? cookies['userToken']
    if (typeof cookieToken === 'string' && cookieToken.length > 0) {
      token = cookieToken
      source = `storageState ${path} (user_token cookie)`
    }
  }
  if (token === undefined || token.length === 0) return null
  return { token, cookies, source }
}

export interface WebAuthOptions {
  /** Playwright storageState JSON path holding the signed-in session. */
  storageStatePath?: string
  /** Credential reference (environment-variable name) for a bare token. */
  tokenEnv?: string
}

/**
 * Resolve the web session for one request.
 * @param options - configured auth sources.
 * @param credentials - optional credentials seam (`ctx.credentials`).
 * @param environment - optional launch environment for ambient variable reads.
 * @returns usable auth facts, or throws `LlmError` (`MISSING_CREDENTIAL`) when
 * none of the configured sources yields a token.
 */
export async function resolveWebAuth(
  options: WebAuthOptions,
  credentials?: CredentialProvider,
  environment?: { get(name: string): { value: string } | undefined },
): Promise<WebAuth> {
  if (options.storageStatePath !== undefined && options.storageStatePath.length > 0) {
    let document: unknown
    try {
      document = JSON.parse(readFileSync(options.storageStatePath, 'utf8'))
    } catch (error) {
      throw new LlmError(
        `dsh-llm-deepseek-web: cannot read storageStatePath ${options.storageStatePath}: ${error instanceof Error ? error.message : String(error)}`,
        'INVALID_CREDENTIAL',
        { cause: error },
      )
    }
    const auth = webAuthFromStorageState(document, options.storageStatePath)
    if (auth !== null) return auth
    throw new LlmError(
      'dsh-llm-deepseek-web: storageStatePath holds no chat.deepseek.com session'
      + ' (no userToken in localStorage and no user_token cookie); re-run scripts/save-login.mjs'
      + ` and verify ${options.storageStatePath}`,
      'MISSING_CREDENTIAL',
    )
  }
  const ref = credentialRef(options.tokenEnv ?? DEFAULT_TOKEN_ENV)
  const resolve = async (): Promise<string | undefined> => {
    if (credentials !== undefined) {
      const hit = await credentials.resolve(ref)
      if (hit !== undefined) return hit.value
    }
    return environment?.get(ref)?.value
  }
  const raw = await resolve()
  if (raw !== undefined && raw.length > 0) {
    return {
      token: assertUsableApiKey(raw, 'dsh-llm-deepseek-web', ref),
      cookies: {},
      source: `credential ${ref}`,
    }
  }
  throw new LlmError(
    'dsh-llm-deepseek-web: no web session; configure storageStatePath (a saved chat.deepseek.com'
    + ` login), or store the session token as ${ref} through the credentials service or environment`,
    'MISSING_CREDENTIAL',
  )
}
