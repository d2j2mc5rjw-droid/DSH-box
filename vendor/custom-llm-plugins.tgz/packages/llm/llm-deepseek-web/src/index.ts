/**
 * Register a {@link WebDeepSeekAdapter} for the `deepseek-web` provider route
 * on `ctx.llm` — the DeepSeek Harness adapter for the **web** edition of
 * DeepSeek (chat.deepseek.com), needing no API key.
 *
 * Connection facts resolve per request instead of freezing at load: the plugin
 * layers its `cordis.yml` entry config under the optional `llm-deepseek-web`
 * user-settings section (`ctx.settings`) and resolves the signed-in web
 * session through the configured `storageStatePath` (a saved chat.deepseek.com
 * login — run `scripts/save-login.mjs`) or a token credential reference, so a
 * refreshed login reaches the very next model call without restarting
 * anything.
 *
 * The web chat protocol has no native function calling; tool schemas are
 * serialized into the prompt and tool calls parsed back out (see
 * `tool-protocol.ts`), so the agent loop still gets executable tool blocks.
 * @module @deepseek-ai/dsh-llm-deepseek-web
 */

import type { Context } from '@deepseek-ai/cordis'
import z from '@deepseek-ai/schemastery'
import { resolveRetryPolicy, RetryPolicySchema } from '@deepseek-ai/dsh-llm'
import type { ResolvedRetryPolicy, RetryPolicyConfig } from '@deepseek-ai/dsh-llm'
import { launchEnvironmentOf } from '@deepseek-ai/dsh-launch-environment'
import { installSettingsSection, settingsNamespace } from '@deepseek-ai/dsh-settings'
import { deepEqualJson } from '@deepseek-ai/dsh-settings'
import { resolveWebAuth } from './auth.ts'
import { WebDeepSeekAdapter } from './adapter.ts'

export { DEFAULT_CONTEXT_WINDOW, WEB_MODELS, WebDeepSeekAdapter } from './adapter.ts'
export type { WebDeepSeekAdapterOptions } from './adapter.ts'
export { powHeader, solvePow } from './pow.ts'
export { WebDeepSeekSession, WEB_BASE } from './session.ts'
export type { WebStreamDelta } from './session.ts'
export { buildPrompt } from './prompt.ts'
export { formatToolInstructions, parseToolCalls } from './tool-protocol.ts'
export type { ParsedToolCall } from './tool-protocol.ts'
export { resolveWebAuth, webAuthFromStorageState } from './auth.ts'
export type { StorageStateFile, WebAuth } from './auth.ts'

export const name = 'llm-deepseek-web'
export const inject = ['llm']

const NS = settingsNamespace('llm-deepseek-web')
const DEFAULT_TOKEN_ENV = 'DEEPSEEK_WEB_TOKEN'
/** The single provider route this plugin owns. */
const PROVIDER = 'deepseek-web'

/**
 * Plugin config, validated by the same-named schemastery schema and doubling
 * as the `llm-deepseek-web` settings-section shape. Every field is optional:
 * a missing session resolves to a clear `MISSING_CREDENTIAL` error at request
 * time, never at plugin load.
 */
export interface Config {
  /** Path to a Playwright storageState JSON holding a signed-in chat.deepseek.com session. */
  storageStatePath?: string
  /** Credential reference (environment-variable name) for a bare web session token; defaults to `DEEPSEEK_WEB_TOKEN`. */
  tokenEnv?: string
  /** Optional pinned chat session id to continue a specific web thread. */
  sessionId?: string
  /** Default thinking mode (web DeepThink toggle); default true. */
  thinking?: boolean
  /** Provider-owned model-request retry policy; omission uses normal defaults. */
  retryPolicy?: RetryPolicyConfig
}


export const Config: z<Config> = z.object({
  storageStatePath: z.string(),
  tokenEnv: z.string().role('credential-ref').default(DEFAULT_TOKEN_ENV),
  sessionId: z.string(),
  thinking: z.boolean().default(true),
  retryPolicy: RetryPolicySchema,
})

/** Validate raw config; re-judged on every settings snapshot and at load. */
export function resolveAdapterOptions(config: Config): ResolvedWebOptions {
  if (config.storageStatePath !== undefined && config.storageStatePath.length === 0) {
    throw new Error('llm-deepseek-web: storageStatePath must not be empty')
  }
  if (config.sessionId !== undefined && config.sessionId.length === 0) {
    throw new Error('llm-deepseek-web: sessionId must not be empty')
  }
  return {
    ...config.storageStatePath === undefined ? {} : { storageStatePath: config.storageStatePath },
    tokenEnv: config.tokenEnv ?? DEFAULT_TOKEN_ENV,
    ...config.sessionId === undefined ? {} : { sessionId: config.sessionId },
    thinking: config.thinking ?? true,
    retryPolicy: resolveRetryPolicy(config.retryPolicy, 'llm-deepseek-web: retryPolicy'),
  }
}

export interface ResolvedWebOptions {
  storageStatePath?: string
  tokenEnv: string
  sessionId?: string
  thinking: boolean
  retryPolicy: ResolvedRetryPolicy
}

export function apply(ctx: Context, config: Config): void {
  let current: () => Config = () => config
  let lastRaw: Config | undefined
  let lastGood: ResolvedWebOptions | undefined
  const options = (): ResolvedWebOptions => {
    const raw = current()
    if (raw === lastRaw && lastGood !== undefined) return lastGood
    try {
      const next = resolveAdapterOptions(raw)
      lastRaw = raw
      lastGood = next
      return next
    } catch (error) {
      if (lastGood === undefined) throw error
      lastRaw = raw
      ctx.logger.error('llm-deepseek-web: keeping the last good configuration after an invalid settings section')
      ctx.logger.error(error)
      return lastGood
    }
  }
  options()

  const adapter = new WebDeepSeekAdapter({
    resolveAuth: async () => resolveWebAuth(
      {
        ...options().storageStatePath === undefined ? {} : { storageStatePath: options().storageStatePath },
        tokenEnv: options().tokenEnv,
      },
      ctx.get('credentials'),
      launchEnvironmentOf(ctx),
    ),
    sessionId: () => options().sessionId,
    thinking: () => options().thinking,
  })
  ctx.llm.registerConfigurableProviders([
    { provider: PROVIDER, displayName: 'DeepSeek Web', settingsNs: NS, settingsPath: [] },
  ])
  const registration = ctx.llm.registerAdapter([PROVIDER], adapter)
  let registeredPolicy = options().retryPolicy
  const ensureRegistrationFacts = (): void => {
    const policy = options().retryPolicy
    if (deepEqualJson(policy, registeredPolicy)) return
    registration.replace([PROVIDER])
    registeredPolicy = policy
  }

  installSettingsSection(ctx, NS, Config, config, {
    setSource: (source) => {
      current = source
    },
    onChange: ensureRegistrationFacts,
  })
}
