/**
 * Flatten DSH conversation messages into the single flat prompt the DeepSeek
 * web chat accepts.
 *
 * The web protocol has no system/role channel and no native tool results, so
 * the adapter serializes everything into one text prompt: the system prompt
 * and system messages first, the tool-use instructions next (when tools are
 * present), then the conversation with role markers. Every request replays the
 * full history, which keeps compaction, resume, and fork correct at the cost
 * of re-sending prior turns on the wire (the same trade the web-API bridges
 * make).
 * @module dsh-llm-deepseek-web/prompt
 */

import type { Message, ToolSchema } from '@deepseek-ai/dsh-llm'
import { formatToolInstructions } from './tool-protocol.ts'

/** Render one block of a message to text; unknown block types degrade to ''. */
function blockText(block: { type: string; text?: unknown; name?: unknown; arguments?: unknown }): string {
  switch (block.type) {
    case 'text':
      return typeof block.text === 'string' ? block.text : ''
    case 'reasoning':
      return typeof block.text === 'string' ? `[reasoning] ${block.text}` : ''
    case 'tool-call':
      return `[tool call: ${String(block.name ?? '')}(${String(block.arguments ?? '')})]`
    case 'image':
      return '[image attachment omitted: the web chat adapter does not send images]'
    default:
      return ''
  }
}

/** Render one message to its role-marked prompt lines ('' for skippable). */
function messageText(message: Message): string {
  switch (message.role) {
    case 'system':
      return message.content.map(blockText).filter((text) => text.length > 0).join('\n')
    case 'user': {
      const lines = message.content.map((block) => {
        if (block.type === 'tool-result') {
          const prefix = block.isError === true ? 'Tool result (error)' : 'Tool result'
          const body = block.content.map(blockText).filter((text) => text.length > 0).join('\n')
          return `${prefix} for call ${block.toolCallId}: ${body}`
        }
        const text = blockText(block as never)
        return text.length > 0 ? `User: ${text}` : ''
      })
      return lines.filter((line) => line.length > 0).join('\n')
    }
    case 'assistant': {
      const lines = message.content.map((block) => {
        if (block.type === 'tool-call') {
          return `Assistant tool call: ${block.name}(${block.arguments})`
        }
        const text = blockText(block as never)
        if (text.length === 0) return ''
        return block.type === 'reasoning' ? `Assistant thinking: ${text}` : `Assistant: ${text}`
      })
      return lines.filter((line) => line.length > 0).join('\n')
    }
    default:
      return ''
  }
}

/**
 * Build the completion prompt for one request.
 * @param system - the harness system prompt.
 * @param messages - ordered conversation messages (system messages included).
 * @param tools - tool schemas to advertise, or undefined for a tool-less call.
 */
export function buildPrompt(
  system: string | undefined,
  messages: readonly Message[],
  tools: readonly ToolSchema[] | undefined,
): string {
  const sections: string[] = []
  const systemParts: string[] = []
  if (system !== undefined && system.length > 0) systemParts.push(system)
  for (const message of messages) {
    if (message.role !== 'system') continue
    const text = messageText(message)
    if (text.length > 0) systemParts.push(text)
  }
  if (systemParts.length > 0) {
    sections.push(systemParts.join('\n\n'))
  }
  const hasTools = tools !== undefined && tools.length > 0
  if (hasTools) {
    sections.push(formatToolInstructions(tools as unknown as ToolSchema[]))
  }
  const conversation = messages
    .filter((message) => message.role !== 'system')
    .map(messageText)
    .filter((text) => text.length > 0)
    .join('\n\n')
  if (conversation.length > 0) {
    sections.push(conversation)
  }
  return sections.join('\n\n')
}

/** Whether the assembled prompt is empty (nothing to send). */
export function promptEmpty(system: string | undefined, messages: readonly Message[]): boolean {
  return buildPrompt(system, messages, undefined).trim().length === 0
}
