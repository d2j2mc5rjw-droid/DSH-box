/**
 * chat.deepseek.com internal API client.
 *
 * Speaks the web app's own wire protocol over plain HTTPS (no browser needed
 * at request time once a signed-in session is captured):
 *
 *   1. `POST /api/v0/chat_session/create` — create (or pin) a chat session.
 *   2. `POST /api/v0/chat/create_pow_challenge` — fetch a PoW challenge.
 *   3. `POST /api/v0/chat/completion` — stream the reply as SSE frames,
 *      carrying `x-ds-pow-response` and the flat `prompt` string.
 *
 * The web protocol has no system/role channel and no native function calling:
 * history, tool schemas, and tool results are flattened into one prompt by the
 * adapter (see `prompt.ts`), and tool calls are parsed back out of the model's
 * text (see `tool-protocol.ts`). Each request is self-contained, so harness
 * compaction, resume, and fork stay correct; messages are chained in one
 * pinned session so the user's chat.deepseek.com sidebar does not fill with a
 * session per model call.
 * @module dsh-llm-deepseek-web/session
 */

import { attributionHeaders, isContextWindowExceededError, isQuotaExceededError, LlmError } from '@deepseek-ai/dsh-llm'
import type { WebAuth } from './auth.ts'
import { powHeader } from './pow.ts'

/** Web origin. */
export const WEB_BASE = 'https://chat.deepseek.com'

/** Completion path, also the PoW `target_path`. */
const COMPLETION_PATH = '/api/v0/chat/completion'

/** Model pill on the wire: `default` = Instant chat model, `expert` = reasoner. */
export type WebModelType = 'default' | 'expert'

/** One completion request; session identity is session-owned state. */
export interface CompletionRequest {
  prompt: string
  modelType?: WebModelType
  thinking: boolean
}

/** One streamed delta decoded from the SSE feed. */
export type WebStreamDelta =
  | { kind: 'text'; text: string }
  | { kind: 'reasoning'; text: string }
  | { kind: 'usage'; inputTokens?: number; outputTokens?: number }

/** Unwrap `data.biz_data`, throwing on API-level errors. */
function bizData(data: { code?: number; msg?: string; data?: { biz_data?: unknown } }): Record<string, unknown> {
  if (data.code !== 0) {
    throw new Error(`DeepSeek web API error: ${data.msg ?? JSON.stringify(data)}`)
  }
  const biz = data.data?.biz_data
  if (typeof biz !== 'object' || biz === null) {
    throw new Error(`DeepSeek web API: unexpected response shape: ${JSON.stringify(data).slice(0, 500)}`)
  }
  return biz as Record<string, unknown>
}

/** Map a failed web response (non-2xx) to a harness LlmError. */
function mapHttpError(status: number, detail: string, cause?: unknown): LlmError {
  const code = status === 401 || status === 403
    ? 'INVALID_CREDENTIAL'
    : status === 429
      ? 'RATE_LIMIT'
      : status >= 500
        ? 'SERVER'
        : isContextWindowExceededError(detail)
          ? 'CONTEXT_WINDOW_EXCEEDED'
          : isQuotaExceededError(detail)
            ? 'QUOTA'
            : 'SERVER'
  return new LlmError(
    `dsh-llm-deepseek-web: web completion failed (HTTP ${status}): ${detail}`,
    code,
    { status, cause },
  )
}

/** Frame payload type for the SSE parser. */
type SseFrame = { v?: unknown; p?: unknown; o?: unknown }

/** The response-object snapshot frame carries fragments and often the message id. */
interface SnapshotFrame {
  response?: {
    fragments?: { type?: string; content?: string }[]
    message_id?: number
  }
  message_id?: number
}

/**
 * A signed-in chat.deepseek.com session. One instance is shared by all
 * requests of the adapter: it owns the pinned chat session and chains each
 * completion onto the previous one so the web thread reads naturally.
 */
export class WebDeepSeekSession {
  private sessionId: string | undefined
  private parentMessageId: number | null = null
  private readonly pinnedSessionId: string | undefined

  constructor(
    private readonly auth: WebAuth,
    options: { sessionId?: string } = {},
  ) {
    this.pinnedSessionId = options.sessionId
  }

  private baseHeaders(): Record<string, string> {
    return {
      ...attributionHeaders(),
      authorization: `Bearer ${this.auth.token}`,
      accept: '*/*',
      'content-type': 'application/json',
      origin: WEB_BASE,
      referer: `${WEB_BASE}/`,
      'x-app-version': '2.0.0',
      'x-client-version': '2.0.0',
      'x-client-platform': 'web',
      'x-client-locale': 'en_US',
      'x-client-bundle-id': 'com.deepseek.chat',
      'x-client-timezone-offset': String(-new Date().getTimezoneOffset()),
    }
  }

  private cookieHeader(): string {
    const entries = Object.entries(this.auth.cookies)
    if (entries.length === 0) return ''
    return entries.map(([name, value]) => `${name}=${value}`).join('; ')
  }

  private async post(
    path: string,
    body: unknown,
    signal?: AbortSignal,
    extraHeaders: Record<string, string> = {},
  ): Promise<Response> {
    const headers = this.baseHeaders()
    const cookie = this.cookieHeader()
    if (cookie !== '') headers.cookie = cookie
    return fetch(`${WEB_BASE}${path}`, {
      method: 'POST',
      headers: { ...headers, ...extraHeaders },
      body: JSON.stringify(body),
      signal: signal ?? null,
    })
  }

  /** Create (or reuse) the pinned chat session; returns its id. */
  private async ensureSession(signal?: AbortSignal): Promise<string> {
    if (this.pinnedSessionId !== undefined) return this.pinnedSessionId
    if (this.sessionId !== undefined) return this.sessionId
    const response = await this.post('/api/v0/chat_session/create', {}, signal)
    if (!response.ok) {
      throw mapHttpError(response.status, await response.text())
    }
    const biz = bizData(await response.json() as { code?: number; msg?: string; data?: { biz_data?: unknown } })
    const session = biz['chat_session']
    if (typeof session !== 'object' || session === null || typeof (session as { id?: unknown })['id'] !== 'string') {
      throw new Error(`DeepSeek web API: chat_session/create returned no session id: ${JSON.stringify(biz).slice(0, 500)}`)
    }
    this.sessionId = (session as { id: string })['id']
    return this.sessionId
  }

  private async powHeaderFor(path: string, signal?: AbortSignal): Promise<string> {
    const response = await this.post('/api/v0/chat/create_pow_challenge', { target_path: path }, signal)
    if (!response.ok) {
      throw mapHttpError(response.status, await response.text())
    }
    const biz = bizData(await response.json() as { code?: number; msg?: string; data?: { biz_data?: unknown } })
    const challenge = biz['challenge']
    if (typeof challenge !== 'object' || challenge === null) {
      throw new Error(`DeepSeek web API: create_pow_challenge returned no challenge: ${JSON.stringify(biz).slice(0, 500)}`)
    }
    return powHeader(challenge as never)
  }

  /**
   * Stream one completion as text/reasoning deltas. On completion the chained
   * parent advances to the new assistant message. Cancellation aborts the
   * fetch and settles promptly (the harness classifies it as an aborted turn).
   */
  async *complete(
    request: CompletionRequest,
    signal?: AbortSignal,
  ): AsyncGenerator<WebStreamDelta> {
    const sessionId = await this.ensureSession(signal)
    const body: Record<string, unknown> = {
      chat_session_id: sessionId,
      parent_message_id: this.parentMessageId,
      prompt: request.prompt,
      ref_file_ids: [],
      thinking_enabled: request.thinking,
      search_enabled: false,
      action: null,
      preempt: false,
    }
    if (request.modelType !== undefined) body['model_type'] = request.modelType
    const pow = await this.powHeaderFor(COMPLETION_PATH, signal)
    const response = await this.post(COMPLETION_PATH, body, signal, { 'x-ds-pow-response': pow })
    if (!response.ok) {
      throw mapHttpError(response.status, await response.text())
    }
    if (response.body === null) {
      throw new LlmError('dsh-llm-deepseek-web: completion response has no body', 'EMPTY_RESPONSE')
    }

    // Pull-queue between the SSE reader and this generator: the reader pushes
    // deltas, the generator yields them in order, and the end marker finishes.
    const queue: (WebStreamDelta | symbol)[] = []
    let resolveWait: (() => void) | undefined
    const push = (delta: WebStreamDelta | symbol): void => {
      queue.push(delta)
      resolveWait?.()
      resolveWait = undefined
    }
    let readerError: unknown
    const readLoop = (async () => {
      try {
        const messageId = await this.consumeSse(response.body as ReadableStream<Uint8Array>, signal, push)
        if (messageId !== undefined) this.parentMessageId = messageId
      } catch (error) {
        readerError = error
      } finally {
        push(END)
      }
    })()
    try {
      while (true) {
        while (queue.length === 0) {
          if (readerError !== undefined) throw readerError
          await new Promise<void>((resolve) => { resolveWait = resolve })
        }
        const delta = queue.shift() as WebStreamDelta | symbol
        if (delta === END) {
          if (readerError !== undefined) throw readerError
          return
        }
        yield delta as WebStreamDelta
      }
    } finally {
      // Stop the background reader when the caller abandons the stream early.
      await readLoop.catch(() => {})
    }
  }

  /** Read and parse the SSE completion body, pushing content deltas to `push`. */
  private async consumeSse(
    body: ReadableStream<Uint8Array>,
    signal: AbortSignal | undefined,
    push: (delta: WebStreamDelta | symbol) => void,
  ): Promise<number | undefined> {
    const reader = body.getReader()
    const decoder = new TextDecoder()
    let buffer = ''
    let activePath: string | undefined
    const fragmentKinds = new Map<string, 'text' | 'reasoning'>()
    let messageId: number | undefined

    const kindOf = (path: string | undefined): 'text' | 'reasoning' => {
      if (path === undefined) return 'text'
      const known = fragmentKinds.get(path)
      if (known !== undefined) return known
      return /thinking|reasoning/i.test(path) ? 'reasoning' : 'text'
    }
    const emit = (kind: 'text' | 'reasoning', text: string): void => {
      if (text.length === 0) return
      push(kind === 'text' ? { kind: 'text', text } : { kind: 'reasoning', text })
    }

    const handleFrame = (payload: string): void => {
      if (payload === '[DONE]') return
      let obj: SseFrame
      try {
        obj = JSON.parse(payload) as SseFrame
      } catch {
        return
      }
      const v = obj['v']
      // Snapshot frame: the complete response object.
      if (typeof v === 'object' && v !== null && 'response' in (v as Record<string, unknown>)) {
        const snapshot = v as unknown as SnapshotFrame
        if (typeof snapshot.response?.message_id === 'number') messageId = snapshot.response.message_id
        else if (typeof snapshot.message_id === 'number') messageId = snapshot.message_id
        const fragments = snapshot.response?.fragments ?? []
        fragments.forEach((fragment, index) => {
          const kind = fragment.type === 'RESPONSE' || fragment.type === undefined ? 'text' : 'reasoning'
          fragmentKinds.set(`response/fragments/${index}/content`, kind)
          if (typeof fragment.content === 'string' && fragment.content.length > 0) {
            emit(kind, fragment.content)
          }
        })
        return
      }
      // Path-setting frame.
      if (typeof obj['p'] === 'string') {
        activePath = obj['p'] as string
        if (typeof v === 'number' && (activePath as string).endsWith('message_id')) {
          messageId = v
        }
        if (obj['o'] === 'APPEND' && typeof v === 'string' && (activePath as string).endsWith('content')) {
          emit(kindOf(activePath), v)
        }
        return
      }
      // Bare append to the active path.
      if (typeof v === 'string' && activePath !== undefined && activePath.endsWith('content')) {
        emit(kindOf(activePath), v)
      }
    }

    for (;;) {
      if (signal?.aborted) {
        await reader.cancel().catch(() => {})
        throw new LlmError('dsh-llm-deepseek-web: request aborted', 'ABORTED', { cause: signal.reason })
      }
      let chunk: ReadableStreamReadResult<Uint8Array>
      try {
        chunk = await reader.read()
      } catch (error) {
        if (signal?.aborted) {
          throw new LlmError('dsh-llm-deepseek-web: request aborted', 'ABORTED', { cause: error })
        }
        throw error
      }
      if (chunk.done) break
      buffer += decoder.decode(chunk.value, { stream: true })
      let index: number
      while ((index = buffer.indexOf('\n')) !== -1) {
        const line = buffer.slice(0, index).trim()
        buffer = buffer.slice(index + 1)
        if (!line.startsWith('data:')) continue
        const payload = line.slice('data:'.length).trim()
        if (payload.length === 0) continue
        handleFrame(payload)
      }
    }
    // Drain a trailing partial line that ended without a newline.
    const tail = buffer.trim()
    if (tail.startsWith('data:')) {
      const payload = tail.slice('data:'.length).trim()
      if (payload.length > 0 && payload !== '[DONE]') handleFrame(payload)
    }
    return messageId
  }
}

/** Sentinel for the end of an SSE stream. */
const END: unique symbol = Symbol('web-sse-end')
