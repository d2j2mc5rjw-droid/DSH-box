/**
 * Text-protocol tool calling for the DeepSeek web chat.
 *
 * chat.deepseek.com exposes no native function calling, so the adapter
 * serializes tool schemas into the prompt and instructs the model to answer
 * tool use with a `<tool_call>` block; this module formats those instructions
 * and parses the model's output back into structured calls. The instruction
 * and parsing formats are battle-tested by the open-source web-API bridges
 * (e.g. `kingkongfft/Free-Deepseek-chat-for-opencode`) and cover the common
 * malformations DeepSeek models emit: XML variants, fenced JSON, attribute
 * forms, and named-parameter forms.
 * @module dsh-llm-deepseek-web/tool-protocol
 */

import type { ToolSchema } from '@deepseek-ai/dsh-llm'

/** One parsed tool call: the raw JSON argument string exactly as emitted. */
export interface ParsedToolCall {
  name: string
  arguments: string
}

/** Format a tool's parameter list for the one-line summary in the prompt. */
function parameterSummary(schema: ToolSchema): string {
  const properties = (schema.parameters?.['properties'] ?? {}) as Record<string, { type?: unknown }>
  const required = new Set<string>(
    Array.isArray(schema.parameters?.['required']) ? schema.parameters['required'] as string[] : [],
  )
  const names = Object.keys(properties)
  if (names.length === 0) return ''
  return names.map((name) => {
    const type = properties[name]?.type ?? ''
    return required.has(name) ? `${name}: ${type}` : `${name}?: ${type}`
  }).join(', ')
}

/** Build the tool-use instruction section appended to the prompt. */
export function formatToolInstructions(tools: readonly ToolSchema[]): string {
  const lines = tools.map((tool) => {
    const params = parameterSummary(tool)
    return `- ${tool.name}(${params})${tool.description ? ` — ${tool.description}` : ''}`
  })
  const example = tools[0]
  const exampleArgs = example !== undefined
    ? summarizeExampleArguments(example)
    : '"key": "value"'
  return [
    '[TOOL USE INSTRUCTIONS — FOLLOW EXACTLY]',
    'You have access to these tools:',
    ...lines,
    '',
    'OUTPUT FORMAT — when you want to call a tool, your ENTIRE response must be ONLY this:',
    '<tool_call>',
    `{"name": "${example?.name ?? 'TOOL_NAME'}", "arguments": {${exampleArgs}}}`,
    '</tool_call>',
    '',
    'Rules:',
    '- Do NOT wrap tool calls in ```json ... ``` markdown code blocks.',
    '- Do NOT write any text before or after the <tool_call> block.',
    '- Do NOT add attributes to the tag: WRONG: <tool_call name="read"> — CORRECT: <tool_call>.',
    '- The JSON inside <tool_call> MUST have "name" and "arguments" keys.',
    '- If no tool is needed, respond normally in plain text.',
    '[END TOOL USE INSTRUCTIONS]',
  ].join('\n')
}

/** Derive a tiny illustrative arguments fragment from the first tool schema. */
function summarizeExampleArguments(tool: ToolSchema): string {
  const properties = (tool.parameters?.['properties'] ?? {}) as Record<string, { type?: unknown }>
  const first = Object.keys(properties)[0]
  if (first === undefined) return '"key": "value"'
  const type = properties[first]?.type
  const value = type === 'boolean' ? 'true' : type === 'number' ? '0' : '"value"'
  return `"${first}": ${value}`
}

/** Tolerantly parse a JSON value from text, stripping markdown fences. */
function parseJsonBlock(raw: string): unknown {
  let cleaned = raw.trim().replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim()
  if (cleaned.endsWith('}') === false && cleaned.includes('}')) {
    // Attribute forms sometimes leave a stray trailing brace; keep the JSON prefix.
    const cut = cleaned.lastIndexOf('}')
    cleaned = cleaned.slice(0, cut + 1)
  }
  try {
    return JSON.parse(cleaned)
  } catch {
    return undefined
  }
}

/** Parse `<parameter name="k">v</parameter>` blocks into a JSON-able record. */
function parseParameterPayload(raw: string): Record<string, unknown> | undefined {
  const pairs = [...raw.matchAll(/<parameter\s+name=["']([^"']+)["'][^>]*>\s*(.*?)\s*<\/parameter>/gs)]
  if (pairs.length === 0) return undefined
  const args: Record<string, unknown> = {}
  for (const match of pairs) {
    const value = parseJsonBlock(match[2] ?? '')
    args[match[1] ?? ''] = value !== undefined ? value : (match[2] ?? '').trim()
  }
  return args
}

function call(name: string, args: unknown): ParsedToolCall {
  return {
    name,
    arguments: typeof args === 'string' ? args : JSON.stringify(args ?? {}),
  }
}

/** Parse tool calls out of a full model reply. */
export function parseToolCalls(text: string, tools: readonly ToolSchema[]): ParsedToolCall[] {
  const found: ParsedToolCall[] = []
  let cleaned = text

  // Format: Anthropic-style <tool_calls><invoke name="fn"><parameter .../></invoke></tool_calls>
  // (possibly wrapped in an outer <tool_call>).
  if (found.length === 0) {
    const anthropic = /<tool_calls>\s*(.*?)\s*<\/tool_calls>/gs.exec(text)
    if (anthropic !== null) {
      const invokes = [...(anthropic[1] ?? '').matchAll(/<invoke\s+name=["']([^"']+)["'][^>]*>([\s\S]*?)<\/invoke>/gs)]
      if (invokes.length > 0) {
        for (const invoke of invokes) {
          const params = parseParameterPayload(invoke[2] ?? '')
          found.push(call(invoke[1] ?? '', params ?? {}))
        }
        cleaned = cleaned.replace(/<tool_calls>[\s\S]*?<\/tool_calls>/gs, '')
      }
    }
  }

  // Format: <tool_call>{"name": ..., "arguments": {...}}</tool_call>
  if (found.length === 0) {
    const body = /<tool_call>\s*(\{.*?\})\s*<\/tool_call>/gs.exec(text)
    if (body !== null) {
      const obj = parseJsonBlock(body[1] ?? '')
      if (typeof obj === 'object' && obj !== null && !Array.isArray(obj)) {
        const record = obj as Record<string, unknown>
        if (typeof record['name'] === 'string' && record['arguments'] !== undefined) {
          found.push(call(record['name'], record['arguments']))
        }
      }
      cleaned = cleaned.replace(/<tool_call>\s*\{.*?\}\s*<\/tool_call>/gs, '')
    }
  }

  // Format: <tool_call name="fn">{args}</tool_call>
  if (found.length === 0) {
    const named = /<tool_call\s+name=["']([^"']+)["']>\s*([\s\S]*?)\s*<\/tool_call>/gs.exec(text)
    if (named !== null) {
      const obj = parseJsonBlock(named[2] ?? '')
      if (obj !== undefined && typeof obj === 'object') {
        found.push(call(named[1] ?? '', obj))
      } else {
        const params = parseParameterPayload(named[2] ?? '')
        found.push(call(named[1] ?? '', params ?? { content: (named[2] ?? '').trim() }))
      }
      cleaned = cleaned.replace(/<tool_call\s+name=["'][^"']+["']>[\s\S]*?<\/tool_call>/gs, '')
    }
  }

  // Format: bare fenced JSON ```json {"name": ..., "arguments": ...} ```
  if (found.length === 0) {
    const fences = [...text.matchAll(/```(?:json)?\s*(\{.*?\})\s*```/gs)]
    for (const fence of fences) {
      const obj = parseJsonBlock(fence[1] ?? '')
      if (typeof obj === 'object' && obj !== null && !Array.isArray(obj)) {
        const record = obj as Record<string, unknown>
        if (typeof record['name'] === 'string' && record['arguments'] !== undefined) {
          found.push(call(record['name'], record['arguments']))
        }
      }
    }
    if (found.length > 0) cleaned = cleaned.replace(/```(?:json)?\s*\{.*?\}\s*```/gs, '')
  }

  // Format: <tool_call name="fn" arguments={...}> (attribute / self-closing)
  if (found.length === 0) {
    const attr = /<tool_call\s+name=["']([^"']+)["'][^>]*\barguments=(\{.*?\})[\s>]/gs.exec(text)
    if (attr !== null) {
      const obj = parseJsonBlock(attr[2] ?? '')
      found.push(call(attr[1] ?? '', obj ?? { content: (attr[2] ?? '').trim() }))
      cleaned = cleaned.replace(/<tool_call\s+name=["'][^"']+["'][^>]*\barguments=(\{.*?\})[\s>]/gs, '')
    }
  }

  // Format: <function-name>fn</function-name><function-params>{...}</function-params>
  if (found.length === 0) {
    const fnName = /<function-name>\s*(.*?)\s*<\/function-name>/gs.exec(text)
    const fnParams = /<function-params>\s*([\s\S]*?)\s*<\/function-params>/gs.exec(text)
    if (fnName !== null) {
      const obj = parseJsonBlock(fnParams?.[1] ?? '')
      const params = obj !== undefined && typeof obj === 'object'
        ? obj
        : (parseParameterPayload(fnParams?.[1] ?? '') ?? { content: (fnParams?.[1] ?? '').trim() })
      found.push(call((fnName[1] ?? '').trim(), params))
      cleaned = cleaned.replace(/<function-name>\s*.*?\s*<\/function-name>/gs, '')
      cleaned = cleaned.replace(/<function-params>\s*[\s\S]*?\s*<\/function-params>/gs, '')
    }
  }

  // Clean any stray tags the model left behind, but only when a tool call was
  // actually found (otherwise the tags are user content).
  if (found.length > 0) {
    cleaned = cleaned
      .replace(/<\/?tool_call>/gi, '')
      .replace(/<\/?tool_calls?>/gi, '')
      .trim()
  }
  void tools
  return found
}
