/**
 * DeepSeek Web proof-of-work solver.
 *
 * chat.deepseek.com gates `POST /api/v0/chat/completion` behind an
 * `x-ds-pow-response` header whose value is produced by DeepSeekHashV1, the
 * same float64-hashing module the website runs in the browser
 * (`sha3_wasm_bg.wasm`). Rather than reimplementing the hash, we execute the
 * exact wasm-bindgen module the site ships, via Node's built-in WebAssembly
 * runtime — the module has no imports, so no sandbox or extra dependency is
 * needed.
 *
 * Wire contract (mirrors the official web app and the open-source
 * `sums001/Deepseek-API` client):
 *   1. `POST /api/v0/chat/create_pow_challenge` with `{"target_path": ...}`
 *      returns `data.biz_data.challenge` = { algorithm, challenge, salt,
 *      expire_at, signature, target_path, difficulty }.
 *   2. Solve `wasm_solve(retptr, challenge, salt_expire_prefix, difficulty)`
 *      where `salt_expire_prefix` = `${salt}_${expire_at}_`.
 *   3. `x-ds-pow-response` = base64(JSON { algorithm, challenge, salt,
 *      answer, signature, target_path }).
 * @module dsh-llm-deepseek-web/pow
 */

import { SHA3_WASM_BASE64 } from './wasm.ts'

/** Decode the embedded wasm bytes once. */
const WASM_BYTES = (() => {
  const binary = Buffer.from(SHA3_WASM_BASE64, 'base64')
  return new Uint8Array(binary.buffer, binary.byteOffset, binary.byteLength)
})()

interface PowChallenge {
  algorithm: string
  challenge: string
  salt: string
  expire_at: number
  signature: string
  target_path: string
  difficulty: number
}

/** The exported wasm-bindgen surface of the DeepSeekHashV1 module. */
interface PowExports {
  memory: WebAssembly.Memory
  wasm_solve: (retptr: number, cPtr: number, cLen: number, pPtr: number, pLen: number, difficulty: number) => void
  __wbindgen_export_0: (size: number, align: number) => number
  __wbindgen_add_to_stack_pointer: (delta: number) => number
}

let cached: PowExports | undefined

/** Instantiate (once) and memoize the DeepSeekHashV1 wasm module. */
function exportsOf(): PowExports {
  if (cached !== undefined) return cached
  const module = new WebAssembly.Module(WASM_BYTES)
  const instance = new WebAssembly.Instance(module, {})
  cached = instance.exports as unknown as PowExports
  return cached
}

/**
 * Solve one PoW challenge. Returns the integer answer, or `null` when the
 * wasm module reports failure (typically an expired challenge).
 */
export function solvePow(challenge: string, prefix: string, difficulty: number): number | null {
  const exp = exportsOf()
  const memory = exp.memory
  const writeUtf8 = (text: string): { ptr: number; len: number } => {
    const data = new TextEncoder().encode(text)
    const ptr = exp.__wbindgen_export_0(data.length, 1)
    new Uint8Array(memory.buffer, ptr, data.length).set(data)
    return { ptr, len: data.length }
  }
  const retptr = exp.__wbindgen_add_to_stack_pointer(-16)
  try {
    const c = writeUtf8(challenge)
    const p = writeUtf8(prefix)
    exp.wasm_solve(retptr, c.ptr, c.len, p.ptr, p.len, difficulty)
    const view = new DataView(memory.buffer)
    const status = view.getInt32(retptr, true)
    const value = view.getFloat64(retptr + 8, true)
    return status === 0 ? null : Math.trunc(value)
  } finally {
    exp.__wbindgen_add_to_stack_pointer(16)
  }
}

/**
 * Build the base64 `x-ds-pow-response` header value from a challenge object.
 * @throws when the challenge cannot be solved (expired or malformed).
 */
export function powHeader(challenge: PowChallenge): string {
  const prefix = `${challenge.salt}_${challenge.expire_at}_`
  const answer = solvePow(challenge.challenge, prefix, challenge.difficulty)
  if (answer === null) {
    throw new Error('dsh-llm-deepseek-web: PoW solver returned no answer (challenge expired?)')
  }
  const payload = {
    algorithm: challenge.algorithm,
    challenge: challenge.challenge,
    salt: challenge.salt,
    answer,
    signature: challenge.signature,
    target_path: challenge.target_path,
  }
  return Buffer.from(JSON.stringify(payload)).toString('base64')
}
