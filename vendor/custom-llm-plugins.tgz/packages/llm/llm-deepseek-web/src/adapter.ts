/**
 * The Web-DeepSeek `LlmAdapter`: streams one model call through the
 * chat.deepseek.com internal API.
 *
 * Auth is resolved per request (a captured `storageState` login or a token
 * credential), the conversation is flattened to the web prompt, the reply is
 * streamed as reasoning/text chunks, and any `<tool_call>` the model emitted
 * is parsed back into harness tool-call blocks so the agent loop can execute
 * it. Block indexes: 0 = reasoning (when present), 1 = text, then one block
 * per parsed tool call. `block-end` carries the cleaned text (tool markup
 * stripped) so the durable message never shows the emulation protocol.
 * @module dsh-llm-deepseek-web/adapter
 */

import { CallId, LlmAdapter, type GenerateOptions, type LlmModelInfo, type LlmProviderInfo, type LlmResolvedModelInfo, type StreamChunk, type ToolSchema } from '@deepseek-ai/dsh-llm'
import type { WebAuth } from './auth.ts'
import { WebDeepSeekSession, type WebModelType } from './session.ts'
import { buildPrompt } from './prompt.ts'
import { parseToolCalls } from './tool-protocol.ts'

/** Context capacity advertised for the web models (the web UI does not disclose one). */
export const DEFAULT_CONTEXT_WINDOW = 128_000

/** Advertised model catalog: the two web model pills. */
export const WEB_MODELS: readonly { id: string; name: string; modelType: WebModelType }[] = [
  { id: 'deepseek-web', name: 'DeepSeek Web (Instant)', modelType: 'default' },
  { id: 'deepseek-web-reasoner', name: 'DeepSeek Web (Reasoner)', modelType: 'expert' },
]

export interface WebDeepSeekAdapterOptions {
  /** Per-request auth resolver; throws `LlmError` when no session is configured. */
  resolveAuth(): Promise<WebAuth>
  /** Optional pinned chat session id (continues that thread); re-read per request. */
  sessionId?: () => string | undefined
  /** Default thinking mode (web DeepThink toggle); default true; re-read per request. */
  thinking?: () => boolean
}

function modelTypeFor(model: string): WebModelType {
  return WEB_MODELS.find((entry) => entry.id === model)?.modelType ?? 'default'
}

function thinkingFor(options: GenerateOptions, adapterDefault: () => boolean): boolean {
  return options.reasoningEffort === 'off' ? false : adapterDefault()
}

/** The adapter instance shared by the `deepseek-web` route. */
export class WebDeepSeekAdapter extends LlmAdapter {
  private session: WebDeepSeekSession | undefined
  private lastAuth: WebAuth | undefined

  constructor(private readonly options: WebDeepSeekAdapterOptions) {
    super()
  }

  override providerInfo(provider: string): LlmProviderInfo {
    return { id: provider, name: 'DeepSeek Web' }
  }

  override async listModels(_provider: string): Promise<readonly LlmModelInfo[]> {
    return WEB_MODELS.map((entry) => ({
      provider: _provider,
      id: entry.id,
      name: entry.name,
      inputModalities: ['text'],
    }))
  }

  override async resolveModel(
    provider: string,
    model: string,
    _signal?: AbortSignal,
  ): Promise<LlmResolvedModelInfo> {
    const catalog = WEB_MODELS.find((entry) => entry.id === model)
    return {
      provider,
      id: model,
      name: catalog?.name ?? model,
      inputModalities: ['text'],
      context: { contextWindow: DEFAULT_CONTEXT_WINDOW },
    }
  }

  /** The shared session for the current auth; recreated when auth changes. */
  private async sessionFor(): Promise<WebDeepSeekSession> {
    const auth = await this.options.resolveAuth()
    const sessionId = this.options.sessionId?.()
    if (this.session === undefined || this.lastAuth?.token !== auth.token) {
      this.session = new WebDeepSeekSession(auth, {
        ...sessionId === undefined ? {} : { sessionId },
      })
      this.lastAuth = auth
    }
    return this.session
  }

  override async *stream(options: GenerateOptions): AsyncIterable<StreamChunk> {
    const prompt = buildPrompt(options.system, options.messages, options.tools)
    if (prompt.trim().length === 0) {
      throw new Error('dsh-llm-deepseek-web: refusing an empty prompt')
    }
    const session = await this.sessionFor()
    const modelType = modelTypeFor(options.model)
    const thinking = thinkingFor(options, this.options.thinking ?? (() => true))

    // Text and reasoning are buffered so the tool parser can rewrite the final
    // text block; deltas still stream out progressively.
    let text = ''
    let reasoning = ''
    let textIndex = -1
    let reasoningIndex = -1

    for await (const delta of session.complete(
      { prompt, modelType, thinking },
      options.signal,
    )) {
      if (delta.kind === 'reasoning') {
        if (reasoningIndex === -1) {
          reasoningIndex = 0
          yield { type: 'block-start', index: 0, blockType: 'reasoning' }
        }
        reasoning += delta.text
        yield { type: 'reasoning-delta', index: 0, text: delta.text }
      } else if (delta.kind === 'text') {
        if (textIndex === -1) {
          textIndex = reasoningIndex === -1 ? 0 : 1
          yield { type: 'block-start', index: textIndex, blockType: 'text' }
        }
        text += delta.text
        yield { type: 'text-delta', index: textIndex, text: delta.text }
      }
    }

    // Parse tool calls out of the completed text.
    const tools = options.tools as ToolSchema[] | undefined
    const parsed = parseToolCalls(text, tools ?? [])
    const cleanedText = parsed.length > 0 ? stripToolCalls(text) : text

    // Close blocks in order; block-end is authoritative for the final message.
    if (reasoningIndex !== -1) {
      yield { type: 'block-end', index: 0, block: { type: 'reasoning', text: reasoning } }
    }
    if (textIndex !== -1) {
      yield { type: 'block-end', index: textIndex, block: { type: 'text', text: cleanedText } }
    }

    // Emit one block per parsed tool call with a stable call id.
    for (const [position, call] of parsed.entries()) {
      const index = textIndex + 1 + position
      const callId = CallId(`call_${position}_${call.name}`)
      yield { type: 'block-start', index, blockType: 'tool-call' }
      yield { type: 'tool-call-delta', index, id: callId, name: call.name, argumentsDelta: call.arguments }
      yield { type: 'block-end', index, block: { type: 'tool-call', id: callId, name: call.name, arguments: call.arguments } }
    }

    yield {
      type: 'finish',
      reason: parsed.length > 0 ? { kind: 'tool-calls' } : { kind: 'stop' },
    }
  }
}

/** Remove tool-call markup from the raw text, matching `parseToolCalls`. */
function stripToolCalls(text: string): string {
  return text
    .replace(/<tool_calls>[\s\S]*?<\/tool_calls>/gs, '')
    .replace(/<tool_call>\s*\{.*?\}\s*<\/tool_call>/gs, '')
    .replace(/<tool_call\s+name=["'][^"']+["']>[\s\S]*?<\/tool_call>/gs, '')
    .replace(/```(?:json)?\s*\{.*?\}\s*```/gs, '')
    .replace(/<tool_call\s+name=["'][^"']+["'][^>]*\barguments=(\{.*?\})[\s>]/gs, '')
    .replace(/<function-name>\s*.*?\s*<\/function-name>/gs, '')
    .replace(/<function-params>\s*[\s\S]*?\s*<\/function-params>/gs, '')
    .replace(/<\/?tool_call>/gi, '')
    .replace(/<\/?tool_calls?>/gi, '')
    .trim()
}
