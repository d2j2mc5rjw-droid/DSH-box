# @deepseek-ai/dsh-llm-deepseek-web

[English](README.md) | 中文

面向 DeepSeek Harness LLM 接缝的**网页版 DeepSeek** 适配器：把 `https://chat.deepseek.com` 的网页版直接当作 provider 使用，用已登录的浏览器会话而不是 API Key。它通过纯 HTTPS 说网页应用自己的内部协议（`/api/v0/chat_session/create`、`/api/v0/chat/create_pow_challenge`、`/api/v0/chat/completion`），并在 Node 内置的 WebAssembly 运行时里运行网站同款的 DeepSeekHashV1 工作量证明 wasm 模块来求解 `x-ds-pow-response` 头。

包根导出 Cordis 插件契约、`WebDeepSeekAdapter`、`WebDeepSeekSession`、PoW 求解器（`powHeader`/`solvePow`）以及 prompt/工具辅助函数。本插件独占 `deepseek-web` 路由，与 `deepseek-official`（API Key 适配器）和 pi-ai 目录里的 `deepseek` 名称相区分。

## 配置

```yaml
- id: llm-deepseek-web
  name: '@deepseek-ai/dsh-llm-deepseek-web'
  config:
    storageStatePath: /Users/you/.dsh/deepseek-web-login.json  # 捕获的登录态；见 scripts/save-login.mjs
    tokenEnv: DEEPSEEK_WEB_TOKEN        # 备选：裸会话 token 的凭据引用
    sessionId:                          # 可选：固定到某个具体网页会话 id
    thinking: true                      # 可选：默认深度思考开关（默认 true）
    retryPolicy:                        # 可选；缺省使用有界的常规默认值
      mode: normal
      maxRetries: 2
```

用户设置段为 `llm-deepseek-web:`（热重载）。认证按请求解析：Playwright `storageState` JSON（由 `scripts/save-login.mjs` 或 `npx playwright codegen --save-storage` 生成）从 `localStorage.userToken` 取 bearer token（回退到 `user_token` cookie）并附带会话 cookie；`tokenEnv` 凭据引用提供裸 token。没有会话时在请求期抛 `LlmError('MISSING_CREDENTIAL')`，而不是加载期。

## 模型

网页版有两个模型胶囊，广告为：

| 模型 id | 线上 `model_type` | 说明 |
|---|---|---|
| `deepseek-web` | `default` | 即时聊天模型 |
| `deepseek-web-reasoner` | `expert` | 深度思考（推理）模型 |

`reasoningEffort: 'off'` 关闭深度思考开关；否则按 `thinking`（默认 true）。网页版不披露上下文容量，适配器广告 128,000 token 窗口。

## 工具调用

chat.deepseek.com 没有原生函数调用。请求携带工具 schema 时，工具定义会序列化进 prompt 并附上严格的 `<tool_call>` 输出指令，模型回复再被解析回 harness 的 `tool-call` 块（覆盖 XML 变体、围栏 JSON、属性形式、命名参数形式），因此 agent 循环仍能执行工具。文本块的 `block-end` 携带剥离了模拟标记的清洗后文本。

## 归属

每个网页请求都携带强制性的 harness `User-Agent` 应用归属（`@deepseek-ai/dsh-llm/attribution`）以及网站期望的浏览器风格头（`origin`、`referer`、`x-client-*`、`x-app-version`）。不发送任何 OpenRouter 专属归属头。

## 模型体验

### deepseek-web / deepseek-web-reasoner

#### 模型看到什么

一段扁平文本 prompt：系统提示与系统消息、工具使用指令（有工具时）、随后是按角色标记序列化的对话（`User:`、`Assistant:`、`Assistant tool call:`、`Tool result for call <id>:`）。每次请求都会重放完整历史；消息链在同一个钉住的网页会话里，避免侧栏被每次模型调用塞满。图片以占位符省略。

#### Token 影响

网页协议是“文本即 prompt”：每次请求都会重发完整历史与工具 schema（除钉住的会话外没有服务端上下文），长 agent 回合的输入成本高于原生工具 API。网页账号自身的使用配额同样生效。

#### KV Cache 影响

没有对 provider 可见的缓存：每次完成都是全新 prompt，适配器不报告 token 用量（网页流不暴露输入/输出统计）。

## 已知限制与待办

- **没有原生函数调用** —— 工具走文本协议模拟；模型若忽略 `<tool_call>` 格式则退化为纯文本（循环将结束回合而非执行工具）。
- **必须登录** —— 先运行一次 `scripts/save-login.mjs`（或把 `storageStatePath` 指向任意捕获的登录态）；token 会轮换，刷新后的登录态按请求生效。
- **网页账号规则适用** —— 限流、配额、风控页面归网站所有；适配器发送 harness 归属 `User-Agent` 及网站期望的浏览器风格头。
- **无图片输入** —— 图片块变为占位符；网页聊天自己的文件上传 API（`ref_file_ids`）未实现。
- **无联网搜索开关** —— `search_enabled` 恒为 false；请改用 harness 的 `web_search` 工具。
- **无用量统计** —— 不发出 `usage` 块。
- **PoW** —— 内嵌的 DeepSeekHashV1 wasm 来自网站 CDN 构建；若网站轮换算法，求解器会以清晰错误失败，直到刷新该资源。
