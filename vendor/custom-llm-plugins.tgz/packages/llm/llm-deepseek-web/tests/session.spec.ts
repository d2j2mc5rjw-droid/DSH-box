/**
 * Session-client tests: the web protocol steps (session create, PoW header,
 * completion SSE) over a stubbed fetch, exercising the SSE parser with
 * realistic snapshot/append frames including thinking fragments.
 * @module dsh-llm-deepseek-web/tests/session
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { WebDeepSeekSession } from '../src/session.ts'
import type { WebAuth } from '../src/auth.ts'

vi.mock('../src/pow.ts', () => ({
  powHeader: vi.fn(() => 'mocked-pow-header'),
  solvePow: vi.fn(() => null),
}))

const AUTH: WebAuth = { token: 'tok123', cookies: { user_token: 'tok123' }, source: 'test' }

/** A fake `Response` carrying an SSE body. */
function sseResponse(...events: string[]): Response {
  const body = events.join('\n') + '\n'
  return new Response(body, { status: 200 })
}

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

const fetchMock = vi.fn()

beforeEach(() => {
  vi.stubGlobal('fetch', fetchMock)
})
afterEach(() => {
  vi.unstubAllGlobals()
  fetchMock.mockReset()
})

describe('WebDeepSeekSession', () => {
  it('creates a session, solves the PoW, and streams text + reasoning deltas', async () => {
    fetchMock
      .mockResolvedValueOnce(jsonResponse({
        code: 0,
        data: { biz_data: { chat_session: { id: 'session-1' } } },
      }))
      .mockResolvedValueOnce(jsonResponse({
        code: 0,
        data: { biz_data: { challenge: { algorithm: 'DeepSeekHashV1' } } },
      }))
      .mockResolvedValueOnce(sseResponse(
        'data: {"v":{"response":{"message_id":7,"fragments":[{"type":"THINKING","content":"let me think"},{"type":"RESPONSE","content":"Hello"}]}}}',
        'data: {"p":"response/fragments/-1/content","o":"APPEND","v":" world"}',
        'data: {"v":"!"}',
        'data: [DONE]',
      ))

    const session = new WebDeepSeekSession(AUTH)
    const deltas = []
    for await (const delta of session.complete({ prompt: 'hi', modelType: 'default', thinking: true })) {
      deltas.push(delta)
    }

    expect(deltas).toEqual([
      { kind: 'reasoning', text: 'let me think' },
      { kind: 'text', text: 'Hello' },
      { kind: 'text', text: ' world' },
      { kind: 'text', text: '!' },
    ])

    // Protocol assertions on the wire.
    const calls = fetchMock.mock.calls
    expect(calls).toHaveLength(3)
    expect(String(calls[0]?.[0])).toBe('https://chat.deepseek.com/api/v0/chat_session/create')
    expect(JSON.parse(String((calls[0]?.[1] as RequestInit).body))).toEqual({})
    expect(String(calls[1]?.[0])).toBe('https://chat.deepseek.com/api/v0/chat/create_pow_challenge')
    expect(JSON.parse(String((calls[1]?.[1] as RequestInit).body))).toEqual({
      target_path: '/api/v0/chat/completion',
    })
    const completion = calls[2]
    expect(String(completion?.[0])).toBe('https://chat.deepseek.com/api/v0/chat/completion')
    const init = completion?.[1] as RequestInit
    expect((init.headers as Record<string, string>)['x-ds-pow-response']).toBe('mocked-pow-header')
    expect((init.headers as Record<string, string>)['authorization']).toBe('Bearer tok123')
    expect((init.headers as Record<string, string>)['cookie']).toContain('user_token=tok123')
    expect(JSON.parse(String(init.body))).toMatchObject({
      chat_session_id: 'session-1',
      parent_message_id: null,
      prompt: 'hi',
      model_type: 'default',
      thinking_enabled: true,
      search_enabled: false,
    })
  })

  it('chains the next completion onto the previous message id', async () => {
    fetchMock
      .mockResolvedValueOnce(jsonResponse({ code: 0, data: { biz_data: { chat_session: { id: 'session-1' } } } }))
      .mockResolvedValueOnce(jsonResponse({ code: 0, data: { biz_data: { challenge: {} } } }))
      .mockResolvedValueOnce(sseResponse(
        'data: {"v":{"response":{"message_id":7,"fragments":[{"type":"RESPONSE","content":"first"}]}}}',
        'data: [DONE]',
      ))
      .mockResolvedValueOnce(jsonResponse({ code: 0, data: { biz_data: { challenge: {} } } }))
      .mockResolvedValueOnce(sseResponse(
        'data: {"v":{"response":{"message_id":8,"fragments":[{"type":"RESPONSE","content":"second"}]}}}',
        'data: [DONE]',
      ))

    const session = new WebDeepSeekSession(AUTH)
    const first = []
    for await (const delta of session.complete({ prompt: 'a', thinking: false })) first.push(delta)
    const second = []
    for await (const delta of session.complete({ prompt: 'b', thinking: false })) second.push(delta)

    expect(first).toEqual([{ kind: 'text', text: 'first' }])
    expect(second).toEqual([{ kind: 'text', text: 'second' }])
    const completionCalls = fetchMock.mock.calls.filter((call) => String(call[0]).endsWith('/chat/completion'))
    expect(JSON.parse(String((completionCalls[0]?.[1] as RequestInit).body))['parent_message_id']).toBeNull()
    expect(JSON.parse(String((completionCalls[1]?.[1] as RequestInit).body))['parent_message_id']).toBe(7)
  })

  it('maps an invalid-token response to INVALID_CREDENTIAL', async () => {
    fetchMock.mockResolvedValueOnce(jsonResponse({
      code: 40003,
      msg: 'Authorization Failed (invalid token)',
    }, 401))
    const session = new WebDeepSeekSession(AUTH)
    await expect(async () => {
      for await (const _ of session.complete({ prompt: 'hi', thinking: false })) { /* drain */ }
    }).rejects.toMatchObject({ code: 'INVALID_CREDENTIAL' })
  })

  it('aborts cleanly when the signal fires mid-stream', async () => {
    // An open-ended body that rejects on abort, like a fetch body wired to the signal.
    const { readable, writable } = new TransformStream<Uint8Array, Uint8Array>()
    const writer = writable.getWriter()
    const controller = new AbortController()
    controller.signal.addEventListener('abort', () => {
      void writer.abort(new Error('fetch aborted'))
    })
    void writer.write(new TextEncoder().encode('data: {"v":{"response":{"fragments":[{"type":"RESPONSE","content":"partial"}]}}}\n'))

    fetchMock
      .mockResolvedValueOnce(jsonResponse({ code: 0, data: { biz_data: { chat_session: { id: 's' } } } }))
      .mockResolvedValueOnce(jsonResponse({ code: 0, data: { biz_data: { challenge: {} } } }))
      .mockResolvedValueOnce(new Response(readable, { status: 200 }))

    const session = new WebDeepSeekSession(AUTH)
    const iterator = session.complete({ prompt: 'hi', thinking: false }, controller.signal)[Symbol.asyncIterator]()
    const first = await iterator.next()
    expect(first.value).toEqual({ kind: 'text', text: 'partial' })
    controller.abort()
    await expect(iterator.next()).rejects.toMatchObject({ code: 'ABORTED' })
  })
})
