/**
 * Tool-protocol tests: instruction formatting and tool-call parsing across the
 * malformation formats DeepSeek models emit.
 * @module dsh-llm-deepseek-web/tests/tool-protocol
 */

import { describe, expect, it } from 'vitest'
import { formatToolInstructions, parseToolCalls } from '../src/tool-protocol.ts'
import type { ToolSchema } from '@deepseek-ai/dsh-llm'

const TOOLS: ToolSchema[] = [
  {
    name: 'bash',
    description: 'Run a shell command',
    parameters: {
      type: 'object',
      properties: { command: { type: 'string' } },
      required: ['command'],
    },
  },
  {
    name: 'read_file',
    description: 'Read a file',
    parameters: {
      type: 'object',
      properties: { path: { type: 'string' }, limit: { type: 'number' } },
    },
  },
]

describe('formatToolInstructions', () => {
  it('lists tools and requires the <tool_call> JSON shape', () => {
    const text = formatToolInstructions(TOOLS)
    expect(text).toContain('[TOOL USE INSTRUCTIONS')
    expect(text).toContain('- bash(command: string) — Run a shell command')
    expect(text).toContain('- read_file(path?: string, limit?: number) — Read a file')
    expect(text).toContain('<tool_call>')
    expect(text).toContain('"name" and "arguments"')
  })
})

describe('parseToolCalls', () => {
  it('parses the canonical JSON-body form', () => {
    const text = '<tool_call>\n{"name": "bash", "arguments": {"command": "ls -la"}}\n</tool_call>'
    const calls = parseToolCalls(text, TOOLS)
    expect(calls).toHaveLength(1)
    expect(calls[0]?.name).toBe('bash')
    expect(JSON.parse(calls[0]?.arguments ?? '{}')).toEqual({ command: 'ls -la' })
  })

  it('parses the named-attribute form', () => {
    const text = '<tool_call name="read_file">{"path": "a.txt"}</tool_call>'
    const calls = parseToolCalls(text, TOOLS)
    expect(calls[0]?.name).toBe('read_file')
    expect(JSON.parse(calls[0]?.arguments ?? '{}')).toEqual({ path: 'a.txt' })
  })

  it('parses fenced JSON', () => {
    const text = '```json\n{"name": "bash", "arguments": {"command": "pwd"}}\n```'
    const calls = parseToolCalls(text, TOOLS)
    expect(calls).toHaveLength(1)
    expect(calls[0]?.name).toBe('bash')
  })

  it('parses Anthropic-style invoke blocks', () => {
    const text = '<tool_calls><invoke name="bash"><parameter name="command">echo hi</parameter></invoke></tool_calls>'
    const calls = parseToolCalls(text, TOOLS)
    expect(calls).toHaveLength(1)
    expect(calls[0]?.name).toBe('bash')
    expect(JSON.parse(calls[0]?.arguments ?? '{}')).toEqual({ command: 'echo hi' })
  })

  it('parses function-name/function-params split form', () => {
    const text = '<function-name>read_file</function-name><function-params>{"path": "b.txt"}</function-params>'
    const calls = parseToolCalls(text, TOOLS)
    expect(calls).toHaveLength(1)
    expect(calls[0]?.name).toBe('read_file')
  })

  it('returns no calls for plain text', () => {
    expect(parseToolCalls('The answer is 42.', TOOLS)).toEqual([])
    expect(parseToolCalls('', TOOLS)).toEqual([])
  })

  it('returns no calls for user content that merely mentions the tags', () => {
    expect(parseToolCalls('Please use <tool_call> syntax next time.', TOOLS)).toEqual([])
  })
})
