/**
 * Adapter tests: the full `stream()` pipeline (auth → prompt → web completion
 * → chunk assembly) over a stubbed fetch, plus storageState auth resolution.
 * @module dsh-llm-deepseek-web/tests/adapter
 */

import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest'
import { createUserMessage, type Message } from '@deepseek-ai/dsh-llm'
import { WebDeepSeekAdapter } from '../src/adapter.ts'
import { webAuthFromStorageState } from '../src/auth.ts'
import type { ToolSchema } from '@deepseek-ai/dsh-llm'

vi.mock('../src/pow.ts', () => ({
  powHeader: vi.fn(() => 'mocked-pow-header'),
  solvePow: vi.fn(() => null),
}))

const TOOLS: ToolSchema[] = [{
  name: 'bash',
  description: 'Run a shell command',
  parameters: { type: 'object', properties: { command: { type: 'string' } }, required: ['command'] },
}]

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { 'content-type': 'application/json' } })
}

function sseResponse(...events: string[]): Response {
  return new Response(events.join('\n') + '\n', { status: 200 })
}

const fetchMock = vi.fn()

beforeEach(() => {
  vi.stubGlobal('fetch', fetchMock)
})
afterEach(() => {
  vi.unstubAllGlobals()
  fetchMock.mockReset()
})

function textUser(text: string): Message {
  return createUserMessage({ content: [{ type: 'text', text }], source: { kind: 'user' } })
}

async function collect(adapter: WebDeepSeekAdapter, options: Parameters<WebDeepSeekAdapter['stream']>[0]): Promise<unknown[]> {
  const chunks = []
  for await (const chunk of adapter.stream(options)) chunks.push(chunk)
  return chunks
}

describe('webAuthFromStorageState', () => {
  it('prefers localStorage userToken over the cookie mirror', () => {
    const auth = webAuthFromStorageState({
      cookies: [{ name: 'user_token', value: 'cookie-token', domain: '.deepseek.com' }],
      origins: [{
        origin: 'https://chat.deepseek.com',
        localStorage: [{ name: 'userToken', value: 'local-token' }],
      }],
    }, 'test.json')
    expect(auth?.token).toBe('local-token')
    expect(auth?.cookies['user_token']).toBe('cookie-token')
  })

  it('falls back to the cookie and filters foreign cookies', () => {
    const auth = webAuthFromStorageState({
      cookies: [
        { name: 'user_token', value: 'cookie-token', domain: '.deepseek.com' },
        { name: 'other', value: 'x', domain: '.example.com' },
      ],
      origins: [],
    }, 'test.json')
    expect(auth?.token).toBe('cookie-token')
    expect(auth?.cookies['other']).toBeUndefined()
  })

  it('returns null without any session', () => {
    expect(webAuthFromStorageState({ cookies: [], origins: [] }, 'test.json')).toBeNull()
  })
})

describe('WebDeepSeekAdapter.stream', () => {
  it('assembles a plain text turn into text chunks and a stop finish', async () => {
    fetchMock
      .mockResolvedValueOnce(jsonResponse({ code: 0, data: { biz_data: { chat_session: { id: 's1' } } } }))
      .mockResolvedValueOnce(jsonResponse({ code: 0, data: { biz_data: { challenge: {} } } }))
      .mockResolvedValueOnce(sseResponse(
        'data: {"v":{"response":{"message_id":1,"fragments":[{"type":"RESPONSE","content":"Hello, world"}]}}}',
        'data: [DONE]',
      ))

    const adapter = new WebDeepSeekAdapter({
      resolveAuth: async () => ({ token: 'tok', cookies: {}, source: 'test' }),
    })
    const chunks = await collect(adapter, {
      provider: 'deepseek-web',
      model: 'deepseek-web',
      messages: [textUser('hi')],
    })

    expect(chunks).toEqual([
      { type: 'block-start', index: 0, blockType: 'text' },
      { type: 'text-delta', index: 0, text: 'Hello, world' },
      { type: 'block-end', index: 0, block: { type: 'text', text: 'Hello, world' } },
      { type: 'finish', reason: { kind: 'stop' } },
    ])
  })

  it('emits reasoning deltas first, then text, with separate blocks', async () => {
    fetchMock
      .mockResolvedValueOnce(jsonResponse({ code: 0, data: { biz_data: { chat_session: { id: 's1' } } } }))
      .mockResolvedValueOnce(jsonResponse({ code: 0, data: { biz_data: { challenge: {} } } }))
      .mockResolvedValueOnce(sseResponse(
        'data: {"v":{"response":{"fragments":[{"type":"THINKING","content":"hmm"},{"type":"RESPONSE","content":"Answer"}]}}}',
        'data: [DONE]',
      ))

    const adapter = new WebDeepSeekAdapter({ resolveAuth: async () => ({ token: 'tok', cookies: {}, source: 'test' }) })
    const chunks = await collect(adapter, {
      provider: 'deepseek-web',
      model: 'deepseek-web-reasoner',
      messages: [textUser('q')],
    })

    const types = chunks.map((chunk) => (chunk as { type: string }).type)
    expect(types).toEqual([
      'block-start', 'reasoning-delta', 'block-start', 'text-delta',
      'block-end', 'block-end', 'finish',
    ])
    expect(chunks[0]).toMatchObject({ blockType: 'reasoning' })
    expect(chunks[2]).toMatchObject({ blockType: 'text' })
    expect(chunks[5]).toMatchObject({ block: { type: 'text', text: 'Answer' } })
  })

  it('parses a tool-call turn into a cleaned text block, a tool-call block, and a tool-calls finish', async () => {
    fetchMock
      .mockResolvedValueOnce(jsonResponse({ code: 0, data: { biz_data: { chat_session: { id: 's1' } } } }))
      .mockResolvedValueOnce(jsonResponse({ code: 0, data: { biz_data: { challenge: {} } } }))
      .mockResolvedValueOnce(sseResponse(
        'data: {"v":{"response":{"fragments":[{"type":"RESPONSE","content":"<tool_call>{\\"name\\": \\"bash\\", \\"arguments\\": {\\"command\\": \\"ls\\"}}</tool_call>"}]}}}',
        'data: [DONE]',
      ))

    const adapter = new WebDeepSeekAdapter({ resolveAuth: async () => ({ token: 'tok', cookies: {}, source: 'test' }) })
    const chunks = await collect(adapter, {
      provider: 'deepseek-web',
      model: 'deepseek-web',
      messages: [textUser('list')],
      tools: TOOLS,
    })

    const textBlock = chunks.find((chunk) => (chunk as { type: string }).type === 'block-end' && (chunk as { block: { type: string } }).block.type === 'text')
    expect((textBlock as { block: { text: string } }).block.text).toBe('')
    const toolBlock = chunks.find((chunk) => (chunk as { type: string }).type === 'block-end' && (chunk as { block: { type: string } }).block.type === 'tool-call')
    expect(toolBlock).toMatchObject({
      block: {
        type: 'tool-call',
        name: 'bash',
        arguments: '{"command":"ls"}',
      },
    })
    const finish = chunks.at(-1)
    expect(finish).toEqual({ type: 'finish', reason: { kind: 'tool-calls' } })
    // The web request carried the flattened prompt including the tool section.
    const completionCall = fetchMock.mock.calls.find((call) => String(call[0]).endsWith('/chat/completion'))
    const body = JSON.parse(String((completionCall?.[1] as RequestInit).body))
    expect(body.prompt).toContain('[TOOL USE INSTRUCTIONS')
    expect(body.prompt).toContain('User: list')
    expect(body.model_type).toBe('default')
  })

  it('fails with MISSING_CREDENTIAL before any web call when no auth is configured', async () => {
    const adapter = new WebDeepSeekAdapter({
      resolveAuth: async () => {
        throw Object.assign(new Error('no session configured'), { code: 'MISSING_CREDENTIAL' })
      },
    })
    await expect(collect(adapter, {
      provider: 'deepseek-web',
      model: 'deepseek-web',
      messages: [textUser('hi')],
    })).rejects.toMatchObject({ code: 'MISSING_CREDENTIAL' })
    expect(fetchMock).not.toHaveBeenCalled()
  })
})
