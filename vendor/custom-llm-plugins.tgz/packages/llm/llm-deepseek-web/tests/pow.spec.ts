/**
 * PoW solver unit tests: the wasm module loads under Node's WebAssembly
 * runtime, garbage challenges fail cleanly, and the header builder produces
 * the documented base64 payload (or a clear error when unsolvable).
 *
 * The success path cannot be exercised without a live challenge from
 * chat.deepseek.com (the module validates the challenge internally), so it is
 * covered by the adapter-level tests with the solver mocked.
 * @module dsh-llm-deepseek-web/tests/pow
 */

import { describe, expect, it } from 'vitest'
import { powHeader, solvePow } from '../src/pow.ts'

describe('solvePow', () => {
  it('instantiates the bundled wasm and exposes the solve ABI', () => {
    // solvePow exercises the module; a garbage challenge must not throw.
    const answer = solvePow('garbage', 'salt_1_', 0.5)
    expect(answer).toBeNull()
  })
})

describe('powHeader', () => {
  it('throws a clear error when the challenge cannot be solved', () => {
    expect(() => powHeader({
      algorithm: 'DeepSeekHashV1',
      challenge: 'garbage',
      salt: 'salt',
      expire_at: 1,
      signature: 'sig',
      target_path: '/api/v0/chat/completion',
      difficulty: 0.5,
    })).toThrow(/PoW solver returned no answer/)
  })
})
