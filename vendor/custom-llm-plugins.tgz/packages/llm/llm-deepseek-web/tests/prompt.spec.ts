/**
 * Prompt-builder tests: DSH messages and tools flatten into the web prompt.
 * @module dsh-llm-deepseek-web/tests/prompt
 */

import { describe, expect, it } from 'vitest'
import { createAssistantMessage, createToolResultMessage, createUserMessage, type Message, type ToolSchema } from '@deepseek-ai/dsh-llm'
import { CallId } from '@deepseek-ai/dsh-llm'
import { buildPrompt, promptEmpty } from '../src/prompt.ts'

const TOOLS: ToolSchema[] = [{
  name: 'bash',
  description: 'Run a shell command',
  parameters: { type: 'object', properties: { command: { type: 'string' } }, required: ['command'] },
}]

function user(text: string): Message {
  return createUserMessage({ content: [{ type: 'text', text }], source: { kind: 'user' } })
}

describe('buildPrompt', () => {
  it('places system, tool instructions, and conversation in order', () => {
    const prompt = buildPrompt('You are a coding agent.', [user('hello')], TOOLS)
    expect(prompt).toContain('You are a coding agent.')
    expect(prompt).toContain('[TOOL USE INSTRUCTIONS')
    expect(prompt).toContain('User: hello')
    expect(prompt.indexOf('You are a coding agent.')).toBeLessThan(prompt.indexOf('[TOOL USE INSTRUCTIONS'))
    expect(prompt.indexOf('[TOOL USE INSTRUCTIONS')).toBeLessThan(prompt.indexOf('User: hello'))
  })

  it('renders multi-turn history with role markers and tool results', () => {
    const result = createToolResultMessage({
      callId: CallId('call_1'),
      content: [{ type: 'text', text: 'ok' }],
      isError: false,
    })
    const toolTurn = createAssistantMessage({
      content: [{ type: 'tool-call', id: CallId('call_1'), name: 'bash', arguments: '{"command":"ls"}' }],
      source: { provider: 'deepseek-web', model: 'deepseek-web' },
    })
    const prompt = buildPrompt(undefined, [
      user('list files'),
      toolTurn,
      result,
      user('thanks'),
    ], TOOLS)
    expect(prompt).toContain('User: list files')
    expect(prompt).toContain('Assistant tool call: bash({"command":"ls"})')
    expect(prompt).toContain('Tool result for call call_1: ok')
    expect(prompt).toContain('User: thanks')
  })

  it('omits the tool section without tools', () => {
    const prompt = buildPrompt('sys', [user('hi')], undefined)
    expect(prompt).not.toContain('[TOOL USE INSTRUCTIONS')
  })

  it('skips image blocks with a placeholder', () => {
    const prompt = buildPrompt(undefined, [createUserMessage({
      content: [{
        type: 'image',
        attachment: { attachmentId: 'a' as never, mediaType: 'image/png', bytes: 1, width: 1, height: 1 },
      }],
      source: { kind: 'user' },
    })], undefined)
    expect(prompt).toContain('image attachment omitted')
  })
})

describe('promptEmpty', () => {
  it('is empty without content', () => {
    expect(promptEmpty(undefined, [])).toBe(true)
    expect(promptEmpty('  ', [])).toBe(true)
  })
  it('is not empty with content', () => {
    expect(promptEmpty('sys', [user('hi')])).toBe(false)
  })
})
