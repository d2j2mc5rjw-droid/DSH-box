# @deepseek-ai/dsh-llm-deepseek-web

English | [中文](README.zh.md)

Web-DeepSeek adapter for the harness LLM seam: drives the **web edition** of DeepSeek (`https://chat.deepseek.com`) as a provider, using the signed-in browser session instead of an API key. Speaks the web app's own internal protocol (`/api/v0/chat_session/create`, `/api/v0/chat/create_pow_challenge`, `/api/v0/chat/completion`) over plain HTTPS, solving the site's DeepSeekHashV1 proof-of-work with the exact wasm module the website runs, in Node's built-in WebAssembly runtime.

The package root exposes the Cordis plugin contract, `WebDeepSeekAdapter`, `WebDeepSeekSession`, the PoW solver (`powHeader`/`solvePow`), and the prompt/tool helpers. The plugin owns the `deepseek-web` provider route, distinct from `deepseek-official` (the API-key adapter) and pi-ai's `deepseek` catalog name.

## Config

```yaml
- id: llm-deepseek-web
  name: '@deepseek-ai/dsh-llm-deepseek-web'
  config:
    storageStatePath: /Users/you/.dsh/deepseek-web-login.json  # captured login; see scripts/save-login.mjs
    tokenEnv: DEEPSEEK_WEB_TOKEN        # alternative: a bare session token credential reference
    sessionId:                          # optional: pin a specific web thread id
    thinking: true                      # optional: default DeepThink toggle (default true)
    retryPolicy:                        # optional; omission uses bounded normal defaults
      mode: normal
      maxRetries: 2
```

The user-settings section is `llm-deepseek-web:` (hot-reloaded). Auth resolves per request: a Playwright `storageState` JSON (produced by `scripts/save-login.mjs` or `npx playwright codegen --save-storage`) supplies the bearer token from `localStorage.userToken` (falling back to the `user_token` cookie) plus the session cookies; a `tokenEnv` credential reference supplies a bare token. No session → `LlmError('MISSING_CREDENTIAL')` at request time, never at load.

## Models

The web app has two model pills, advertised as:

| Model id | Wire `model_type` | Notes |
|---|---|---|
| `deepseek-web` | `default` | Instant chat model |
| `deepseek-web-reasoner` | `expert` | Reasoner (deep-think) model |

`reasoningEffort: 'off'` disables the DeepThink toggle; otherwise `thinking` (default true) applies. The web UI does not disclose context capacities; the adapter advertises a 128,000-token window.

## Tool calling

chat.deepseek.com has no native function calling. When the request carries tool schemas they are serialized into the prompt with strict `<tool_call>` output instructions, and the model's reply is parsed back into harness `tool-call` blocks (XML variants, fenced JSON, attribute forms, named-parameter forms), so the agent loop still executes tools. The text block's `block-end` carries the cleaned text with the emulation markup stripped.

## Attribution

Every web request carries the mandatory harness `User-Agent` app attribution (`@deepseek-ai/dsh-llm/attribution`) together with the site's expected browser headers (`origin`, `referer`, `x-client-*`, `x-app-version`). No OpenRouter-specific attribution headers are sent.

## Model Experience

### deepseek-web / deepseek-web-reasoner

#### What the model sees

One flat text prompt: the system prompt and system messages, the tool-use instructions (when tools are present), then the conversation serialized with role markers (`User:`, `Assistant:`, `Assistant tool call:`, `Tool result for call <id>:`). Every request replays the full history; messages chain in one pinned chat session so the web sidebar does not fill with a session per model call. Images are omitted with a placeholder.

#### Token effect

The web protocol is prompt-as-text: full history and tool schemas are re-sent on every request (no server-side context beyond the pinned session), so long agent turns cost more input than a native-tools API would. The web account's own usage quota applies.

#### KV Cache effect

No provider-visible cache: each completion is a fresh prompt, and the adapter reports no token usage (the web stream does not expose prompt/completion accounting).

## Known Limitations and Deferred Work

- **No native function calling** — tool use goes through the text-protocol emulation; model responses that ignore the `<tool_call>` format degrade to plain text (the loop then ends the turn instead of executing a tool).
- **Login is required** — run `scripts/save-login.mjs` once (or point `storageStatePath` at any captured login); the session token rotates and a refreshed login is picked up per request.
- **Web account rules apply** — rate limits, quota, and abuse screens are the website's; the adapter sends the harness attribution `User-Agent` plus the browser-style headers the site expects.
- **No image input** — image blocks become a placeholder; the web chat's own file-upload API (`ref_file_ids`) is not implemented.
- **No web-search toggle** — `search_enabled` is always false; use the harness `web_search` tool instead.
- **Usage accounting absent** — no `usage` chunk is emitted.
- **PoW** — the DeepSeekHashV1 wasm is embedded from the website's CDN build; if the site rotates the algorithm the solver fails with a clear error until the asset is refreshed.
