/**
 * Web-DeepSeek authentication resolution.
 *
 * chat.deepseek.com does not need an API key: it authenticates with the
 * browser session's bearer token (`localStorage.userToken`, also mirrored in
 * the HttpOnly `user_token` cookie) plus the session cookies. This module
 * resolves those facts from a Playwright `storageState` JSON (the format the
 * `dsh-browser` plugin and `scripts/save-login.mjs` produce) or from a
 * credential reference naming an environment variable.
 *
 * Like the API-key adapters, every fact is resolved per request rather than
 * frozen at load, so a refreshed login reaches the very next model call.
 * @module dsh-llm-deepseek-web/auth
 */
import type { CredentialProvider } from '@deepseek-ai/dsh-credentials';
/** Fallback token source: a Playwright storageState JSON (login capture). */
export declare const DEFAULT_TOKEN_ENV = "DEEPSEEK_WEB_TOKEN";
/** Chrome-ish UA expected by the web origin; not authentication, only hygiene. */
export declare const WEB_USER_AGENT = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";
/** A usable signed-in web session. */
export interface WebAuth {
    /** Bearer token for `Authorization: Bearer <token>`. */
    readonly token: string;
    /** Session cookies to send on every web-origin request. */
    readonly cookies: Record<string, string>;
    /** Where the token came from, for diagnostics. */
    readonly source: string;
}
/** Playwright storageState JSON shape (subset). */
export interface StorageStateFile {
    cookies?: {
        name: string;
        value: string;
        domain?: string;
    }[];
    origins?: {
        origin: string;
        localStorage?: {
            name: string;
            value: string;
        }[];
    }[];
}
/** Parse a storageState document and extract the DeepSeek web session. */
export declare function webAuthFromStorageState(document: unknown, path: string): WebAuth | null;
export interface WebAuthOptions {
    /** Playwright storageState JSON path holding the signed-in session. */
    storageStatePath?: string;
    /** Credential reference (environment-variable name) for a bare token. */
    tokenEnv?: string;
}
/**
 * Resolve the web session for one request.
 * @param options - configured auth sources.
 * @param credentials - optional credentials seam (`ctx.credentials`).
 * @param environment - optional launch environment for ambient variable reads.
 * @returns usable auth facts, or throws `LlmError` (`MISSING_CREDENTIAL`) when
 * none of the configured sources yields a token.
 */
export declare function resolveWebAuth(options: WebAuthOptions, credentials?: CredentialProvider, environment?: {
    get(name: string): {
        value: string;
    } | undefined;
}): Promise<WebAuth>;
//# sourceMappingURL=auth.d.ts.map