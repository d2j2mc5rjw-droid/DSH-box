/**
 * Flatten DSH conversation messages into the single flat prompt the DeepSeek
 * web chat accepts.
 *
 * The web protocol has no system/role channel and no native tool results, so
 * the adapter serializes everything into one text prompt: the system prompt
 * and system messages first, the tool-use instructions next (when tools are
 * present), then the conversation with role markers. Every request replays the
 * full history, which keeps compaction, resume, and fork correct at the cost
 * of re-sending prior turns on the wire (the same trade the web-API bridges
 * make).
 * @module dsh-llm-deepseek-web/prompt
 */
import type { Message, ToolSchema } from '@deepseek-ai/dsh-llm';
/**
 * Build the completion prompt for one request.
 * @param system - the harness system prompt.
 * @param messages - ordered conversation messages (system messages included).
 * @param tools - tool schemas to advertise, or undefined for a tool-less call.
 */
export declare function buildPrompt(system: string | undefined, messages: readonly Message[], tools: readonly ToolSchema[] | undefined): string;
/** Whether the assembled prompt is empty (nothing to send). */
export declare function promptEmpty(system: string | undefined, messages: readonly Message[]): boolean;
//# sourceMappingURL=prompt.d.ts.map