/**
 * chat.deepseek.com internal API client.
 *
 * Speaks the web app's own wire protocol over plain HTTPS (no browser needed
 * at request time once a signed-in session is captured):
 *
 *   1. `POST /api/v0/chat_session/create` — create (or pin) a chat session.
 *   2. `POST /api/v0/chat/create_pow_challenge` — fetch a PoW challenge.
 *   3. `POST /api/v0/chat/completion` — stream the reply as SSE frames,
 *      carrying `x-ds-pow-response` and the flat `prompt` string.
 *
 * The web protocol has no system/role channel and no native function calling:
 * history, tool schemas, and tool results are flattened into one prompt by the
 * adapter (see `prompt.ts`), and tool calls are parsed back out of the model's
 * text (see `tool-protocol.ts`). Each request is self-contained, so harness
 * compaction, resume, and fork stay correct; messages are chained in one
 * pinned session so the user's chat.deepseek.com sidebar does not fill with a
 * session per model call.
 * @module dsh-llm-deepseek-web/session
 */
import type { WebAuth } from './auth.ts';
/** Web origin. */
export declare const WEB_BASE = "https://chat.deepseek.com";
/** Model pill on the wire: `default` = Instant chat model, `expert` = reasoner. */
export type WebModelType = 'default' | 'expert';
/** One completion request; session identity is session-owned state. */
export interface CompletionRequest {
    prompt: string;
    modelType?: WebModelType;
    thinking: boolean;
}
/** One streamed delta decoded from the SSE feed. */
export type WebStreamDelta = {
    kind: 'text';
    text: string;
} | {
    kind: 'reasoning';
    text: string;
} | {
    kind: 'usage';
    inputTokens?: number;
    outputTokens?: number;
};
/**
 * A signed-in chat.deepseek.com session. One instance is shared by all
 * requests of the adapter: it owns the pinned chat session and chains each
 * completion onto the previous one so the web thread reads naturally.
 */
export declare class WebDeepSeekSession {
    private readonly auth;
    private sessionId;
    private parentMessageId;
    private readonly pinnedSessionId;
    constructor(auth: WebAuth, options?: {
        sessionId?: string;
    });
    private baseHeaders;
    private cookieHeader;
    private post;
    /** Create (or reuse) the pinned chat session; returns its id. */
    private ensureSession;
    private powHeaderFor;
    /**
     * Stream one completion as text/reasoning deltas. On completion the chained
     * parent advances to the new assistant message. Cancellation aborts the
     * fetch and settles promptly (the harness classifies it as an aborted turn).
     */
    complete(request: CompletionRequest, signal?: AbortSignal): AsyncGenerator<WebStreamDelta>;
    /** Read and parse the SSE completion body, pushing content deltas to `push`. */
    private consumeSse;
}
//# sourceMappingURL=session.d.ts.map