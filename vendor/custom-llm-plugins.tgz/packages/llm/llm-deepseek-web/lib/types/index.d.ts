/**
 * Register a {@link WebDeepSeekAdapter} for the `deepseek-web` provider route
 * on `ctx.llm` — the DeepSeek Harness adapter for the **web** edition of
 * DeepSeek (chat.deepseek.com), needing no API key.
 *
 * Connection facts resolve per request instead of freezing at load: the plugin
 * layers its `cordis.yml` entry config under the optional `llm-deepseek-web`
 * user-settings section (`ctx.settings`) and resolves the signed-in web
 * session through the configured `storageStatePath` (a saved chat.deepseek.com
 * login — run `scripts/save-login.mjs`) or a token credential reference, so a
 * refreshed login reaches the very next model call without restarting
 * anything.
 *
 * The web chat protocol has no native function calling; tool schemas are
 * serialized into the prompt and tool calls parsed back out (see
 * `tool-protocol.ts`), so the agent loop still gets executable tool blocks.
 * @module @deepseek-ai/dsh-llm-deepseek-web
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ResolvedRetryPolicy, RetryPolicyConfig } from '@deepseek-ai/dsh-llm';
export { DEFAULT_CONTEXT_WINDOW, WEB_MODELS, WebDeepSeekAdapter } from './adapter.ts';
export type { WebDeepSeekAdapterOptions } from './adapter.ts';
export { powHeader, solvePow } from './pow.ts';
export { WebDeepSeekSession, WEB_BASE } from './session.ts';
export type { WebStreamDelta } from './session.ts';
export { buildPrompt } from './prompt.ts';
export { formatToolInstructions, parseToolCalls } from './tool-protocol.ts';
export type { ParsedToolCall } from './tool-protocol.ts';
export { resolveWebAuth, webAuthFromStorageState } from './auth.ts';
export type { StorageStateFile, WebAuth } from './auth.ts';
export declare const name = "llm-deepseek-web";
export declare const inject: string[];
/**
 * Plugin config, validated by the same-named schemastery schema and doubling
 * as the `llm-deepseek-web` settings-section shape. Every field is optional:
 * a missing session resolves to a clear `MISSING_CREDENTIAL` error at request
 * time, never at plugin load.
 */
export interface Config {
    /** Path to a Playwright storageState JSON holding a signed-in chat.deepseek.com session. */
    storageStatePath?: string;
    /** Credential reference (environment-variable name) for a bare web session token; defaults to `DEEPSEEK_WEB_TOKEN`. */
    tokenEnv?: string;
    /** Optional pinned chat session id to continue a specific web thread. */
    sessionId?: string;
    /** Default thinking mode (web DeepThink toggle); default true. */
    thinking?: boolean;
    /** Provider-owned model-request retry policy; omission uses normal defaults. */
    retryPolicy?: RetryPolicyConfig;
}
export declare const Config: z<Config>;
/** Validate raw config; re-judged on every settings snapshot and at load. */
export declare function resolveAdapterOptions(config: Config): ResolvedWebOptions;
export interface ResolvedWebOptions {
    storageStatePath?: string;
    tokenEnv: string;
    sessionId?: string;
    thinking: boolean;
    retryPolicy: ResolvedRetryPolicy;
}
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map