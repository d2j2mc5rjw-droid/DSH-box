/**
 * Text-protocol tool calling for the DeepSeek web chat.
 *
 * chat.deepseek.com exposes no native function calling, so the adapter
 * serializes tool schemas into the prompt and instructs the model to answer
 * tool use with a `<tool_call>` block; this module formats those instructions
 * and parses the model's output back into structured calls. The instruction
 * and parsing formats are battle-tested by the open-source web-API bridges
 * (e.g. `kingkongfft/Free-Deepseek-chat-for-opencode`) and cover the common
 * malformations DeepSeek models emit: XML variants, fenced JSON, attribute
 * forms, and named-parameter forms.
 * @module dsh-llm-deepseek-web/tool-protocol
 */
import type { ToolSchema } from '@deepseek-ai/dsh-llm';
/** One parsed tool call: the raw JSON argument string exactly as emitted. */
export interface ParsedToolCall {
    name: string;
    arguments: string;
}
/** Build the tool-use instruction section appended to the prompt. */
export declare function formatToolInstructions(tools: readonly ToolSchema[]): string;
/** Parse tool calls out of a full model reply. */
export declare function parseToolCalls(text: string, tools: readonly ToolSchema[]): ParsedToolCall[];
//# sourceMappingURL=tool-protocol.d.ts.map