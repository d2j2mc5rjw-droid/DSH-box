/**
 * The Web-DeepSeek `LlmAdapter`: streams one model call through the
 * chat.deepseek.com internal API.
 *
 * Auth is resolved per request (a captured `storageState` login or a token
 * credential), the conversation is flattened to the web prompt, the reply is
 * streamed as reasoning/text chunks, and any `<tool_call>` the model emitted
 * is parsed back into harness tool-call blocks so the agent loop can execute
 * it. Block indexes: 0 = reasoning (when present), 1 = text, then one block
 * per parsed tool call. `block-end` carries the cleaned text (tool markup
 * stripped) so the durable message never shows the emulation protocol.
 * @module dsh-llm-deepseek-web/adapter
 */
import { LlmAdapter, type GenerateOptions, type LlmModelInfo, type LlmProviderInfo, type LlmResolvedModelInfo, type StreamChunk } from '@deepseek-ai/dsh-llm';
import type { WebAuth } from './auth.ts';
import { type WebModelType } from './session.ts';
/** Context capacity advertised for the web models (the web UI does not disclose one). */
export declare const DEFAULT_CONTEXT_WINDOW = 128000;
/** Advertised model catalog: the two web model pills. */
export declare const WEB_MODELS: readonly {
    id: string;
    name: string;
    modelType: WebModelType;
}[];
export interface WebDeepSeekAdapterOptions {
    /** Per-request auth resolver; throws `LlmError` when no session is configured. */
    resolveAuth(): Promise<WebAuth>;
    /** Optional pinned chat session id (continues that thread); re-read per request. */
    sessionId?: () => string | undefined;
    /** Default thinking mode (web DeepThink toggle); default true; re-read per request. */
    thinking?: () => boolean;
}
/** The adapter instance shared by the `deepseek-web` route. */
export declare class WebDeepSeekAdapter extends LlmAdapter {
    private readonly options;
    private session;
    private lastAuth;
    constructor(options: WebDeepSeekAdapterOptions);
    providerInfo(provider: string): LlmProviderInfo;
    listModels(_provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string, _signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
    /** The shared session for the current auth; recreated when auth changes. */
    private sessionFor;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
//# sourceMappingURL=adapter.d.ts.map