/**
 * DeepSeek Web proof-of-work solver.
 *
 * chat.deepseek.com gates `POST /api/v0/chat/completion` behind an
 * `x-ds-pow-response` header whose value is produced by DeepSeekHashV1, the
 * same float64-hashing module the website runs in the browser
 * (`sha3_wasm_bg.wasm`). Rather than reimplementing the hash, we execute the
 * exact wasm-bindgen module the site ships, via Node's built-in WebAssembly
 * runtime — the module has no imports, so no sandbox or extra dependency is
 * needed.
 *
 * Wire contract (mirrors the official web app and the open-source
 * `sums001/Deepseek-API` client):
 *   1. `POST /api/v0/chat/create_pow_challenge` with `{"target_path": ...}`
 *      returns `data.biz_data.challenge` = { algorithm, challenge, salt,
 *      expire_at, signature, target_path, difficulty }.
 *   2. Solve `wasm_solve(retptr, challenge, salt_expire_prefix, difficulty)`
 *      where `salt_expire_prefix` = `${salt}_${expire_at}_`.
 *   3. `x-ds-pow-response` = base64(JSON { algorithm, challenge, salt,
 *      answer, signature, target_path }).
 * @module dsh-llm-deepseek-web/pow
 */
interface PowChallenge {
    algorithm: string;
    challenge: string;
    salt: string;
    expire_at: number;
    signature: string;
    target_path: string;
    difficulty: number;
}
/**
 * Solve one PoW challenge. Returns the integer answer, or `null` when the
 * wasm module reports failure (typically an expired challenge).
 */
export declare function solvePow(challenge: string, prefix: string, difficulty: number): number | null;
/**
 * Build the base64 `x-ds-pow-response` header value from a challenge object.
 * @throws when the challenge cannot be solved (expired or malformed).
 */
export declare function powHeader(challenge: PowChallenge): string;
export {};
//# sourceMappingURL=pow.d.ts.map